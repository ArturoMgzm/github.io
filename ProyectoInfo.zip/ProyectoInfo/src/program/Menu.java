package program;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.awt.event.ActionEvent;
import java.awt.Image;
import javax.imageio.ImageIO;

public class Menu extends JFrame {

	private JPanel contentPane;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setTitle("Menu principal");
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
					String direccion = "/logo.jpg";
					URL url = this.getClass().getResource(direccion);
					ImageIcon icono = new ImageIcon(url);
					Image top = icono.getImage();
					frame.setIconImage(top);
				} catch (Exception e) {
					e.printStackTrace();
					}
				}
			});
		}

	public Menu() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 410, 291);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMen = new JLabel("Men\u00FA");
		lblMen.setBackground(Color.BLUE);
		lblMen.setForeground(Color.BLUE);
		lblMen.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblMen.setBounds(194, 11, 60, 27);
		contentPane.add(lblMen);
		
		JButton ghButton = new JButton("Gestionar Horario");
		ghButton.setForeground(Color.BLUE);
		ghButton.setFont(new Font("Arial", Font.PLAIN, 16));
		ghButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionesGestionar nxtframe = new OpcionesGestionar();
				nxtframe.setTitle("Gesti�n de Horarios");
				nxtframe.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				nxtframe.setVisible(true);
				dispose();
			}
		});
		
		ghButton.setBounds(10, 47, 165, 70);
		ghButton.setToolTipText("Crear / Editar / Eliminar");
		contentPane.add(ghButton);
		
		JButton vhButton = new JButton("Visualizar Horario");
		vhButton.setFont(new Font("Arial", Font.PLAIN, 16));
		vhButton.setForeground(Color.BLUE);
		vhButton.setBounds(10, 115, 165, 70);
		contentPane.add(vhButton);
		vhButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscadorVisualizador nxtframe = new buscadorVisualizador();
				nxtframe.setTitle("Selecci�n para visualizar");
				nxtframe.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				nxtframe.setVisible(true);
				dispose();
			}
		});
		
		JButton ihButton = new JButton("Imprimir Horario");
		ihButton.setForeground(Color.BLUE);
		ihButton.setFont(new Font("Arial", Font.PLAIN, 16));
		ihButton.setBounds(10, 180, 165, 70);
		ihButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscadorImprimir nxtframe = new buscadorImprimir();
				nxtframe.setTitle("Selecci�n para imprimir");
				nxtframe.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				nxtframe.setVisible(true);
				dispose();
			}
		});
		contentPane.add(ihButton);
		
		String direccion = "/logo.jpg";
		URL url = this.getClass().getResource(direccion);
		ImageIcon imagen=new ImageIcon(url);
		JLabel lblTEC = new JLabel("");
		lblTEC.setBounds(194, 49, 230, 201);
		contentPane.add(lblTEC);
		lblTEC.setIcon(imagen);
		
	}
}