package program;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.image.*;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Component;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Eliminar extends JFrame {

	private JPanel contentPane;
	private JTextField textField_30;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Eliminar frame = new Eliminar(0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default: break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     } // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	public static void actualizar(Maestro maestros[], int e){
	maestros[e].setNombre(" ");
	for(int d = 0; d < 5; d++){
		for(int h = 0; h < 10; h++){
			maestros[e].setClase(" ", h, d);
			maestros[e].setGrupo(" ", h, d);
			maestros[e].setSalon(" ", h, d);
		}
	}
	}
	
	 public static void guardar(Maestro maestros[]) throws IOException{
		   fileOut=new PrintWriter(new FileWriter("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		   String linea = "";
		   for(int y = 0; y<maestros.length;y++){
			   fileOut.println(maestros[y].getNombre() + "/");
		for(int dia = 0; dia<5;dia++){
		   for(int x = 0; x<10;x++){
			   switch(dia){
				   case 0: linea = "L" + maestros[y].getClase(x, dia) + "/L" + maestros[y].getSalon(x, dia) + "/L" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 1: linea = "M" + maestros[y].getClase(x, dia) + "/M" + maestros[y].getSalon(x, dia) + "/M" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 2: linea = "I" + maestros[y].getClase(x, dia) + "/I" + maestros[y].getSalon(x, dia) + "/I" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 3: linea = "J" + maestros[y].getClase(x, dia) + "/J" + maestros[y].getSalon(x, dia) + "/J" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 4: linea = "V" + maestros[y].getClase(x, dia) + "/V" + maestros[y].getSalon(x, dia) + "/V" + maestros[y].getGrupo(x, dia) + "/"; break;
				   default:break;}
			   
		   fileOut.println(linea);
	 }}}
		 fileOut.close();
		 }
	
	
	public Eliminar(int este) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 545, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		JLabel lblNewLabel = new JLabel("�Esta seguro que quiere eliminar este horario?");
		lblNewLabel.setForeground(new Color(0, 0, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel.setBounds(74, 11, 376, 29);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Los datos eliminados no podran ser recuperados.");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(79, 25, 366, 41);
		contentPane.add(lblNewLabel_1);
		
		JButton ok = new JButton("Continuar");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) {
				actualizar(maestros,este);
				try {
					guardar(maestros);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				OpcionesGestionar pstframe = new OpcionesGestionar();
				pstframe.setLocationRelativeTo(null);
				pstframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				pstframe.setIconImage(top);
				dispose();
			}
		});
		ok.setBounds(192, 79, 140, 70);
		contentPane.add(ok);
		
		JLabel lblWarning = new JLabel("");
		lblWarning.setBounds(10, 79, 115, 100);
		contentPane.add(lblWarning);
		String direccion = "/warning.png";
		URL url = this.getClass().getResource(direccion);
		ImageIcon icono = new ImageIcon(url);
		lblWarning.setIcon(icono);
		
		JButton cancl = new JButton("Cancelar");
		cancl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionesGestionar pstframe = new OpcionesGestionar();
				pstframe.setLocationRelativeTo(null);
				pstframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				pstframe.setIconImage(top);
				dispose();
			}
		});
		cancl.setBounds(192, 160, 140, 70);
		contentPane.add(cancl);
	}
}
