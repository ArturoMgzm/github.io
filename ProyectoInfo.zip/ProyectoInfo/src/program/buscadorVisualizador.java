package program;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.StringTokenizer;
import java.util.Vector;
import java.io.*;
import java.net.URL;
import java.util.*;

import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import program.BuscadorEditar.buscar;

public class buscadorVisualizador extends JFrame {

	private JPanel contentPane;
	private JTextField txtMaestro;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];

	/**
	 * Launch the application.
	 */
	
	public class buscar extends Thread {

	    public void run() {
	    	String strMaestro = txtMaestro.getText();
			int parecidos = 0;
			int dif = 0;
			int p1 = -1, p2 = -1, p3 = -1;
			int este = -1;
			int aca = 0;
			for (int x = 0; x < maestros.length;x++){
				if ( strMaestro.equalsIgnoreCase(maestros[x].getNombre())){
					este = aca; 
				}
				aca++;
				}
			if (este != -1){
				Visualizacion nxtframe = new Visualizacion(0,este);
				nxtframe.setLocationRelativeTo(null);
				nxtframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				nxtframe.setTitle(maestros[este].getNombre());
				dispose();
			}
			
			int o = 0;
			for(int x = 0; x < 100; x++){
				if(maestros[x].getNombre() != " " && maestros[x].getNombre().length() >= 2){ 
					o++;
				}}
			int d = 0;
			String[] maestroses = new String[o];
			for(int x = 0; x <100; x++){
				if(maestros[x].getNombre() != " "  && maestros[x].getNombre().length() >= 2){
				maestroses[d] = maestros[x].getNombre();
				d++;}
			}
			for(int y = 0; y<maestroses.length;y++){
				for(int z = 0; z < maestroses[y].length();z++){
					if(z < strMaestro.length()){
				if (Character.toLowerCase(strMaestro.charAt(z)) != Character.toLowerCase(maestroses[y].charAt(z))){
					dif++;
				}}}
				if (dif <= 3 && parecidos < 3 && strMaestro.length() >= 3){
					switch (parecidos){
					case 0: p1 = y;break;
					case 1: p2 = y;break;
					case 2: p3 = y;break;
					default:break;
					}
					parecidos++;
				}
				dif = 0;
			}
			JLabel warning1 = new JLabel("No se encontro ese horario");
			warning1.setHorizontalAlignment(SwingConstants.CENTER);
			warning1.setFont(new Font("Times New Roman", Font.ITALIC, 13));
			warning1.setBounds(166, 108, 258, 14);
			contentPane.add(warning1);
			repaint();
			
			if (parecidos != 0){
				JLabel warning2 = new JLabel("Horarios relacionados:");
				warning2.setHorizontalAlignment(SwingConstants.CENTER);
				warning2.setFont(new Font("Times New Roman", Font.ITALIC, 13));
				warning2.setBounds(166, 133, 258, 14);
				contentPane.add(warning2);
				switch (parecidos){
					case 1: 
						JButton btnP1 = new JButton(maestros[p1].getNombre());
						final int llevar = p1;
						btnP1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Visualizacion nxtframe = new Visualizacion(0,llevar);
								nxtframe.setLocationRelativeTo(null);
								nxtframe.setVisible(true);
								String direccion = "/logo.jpg";
								URL url = this.getClass().getResource(direccion);
								ImageIcon icono = new ImageIcon(url);
								Image top = icono.getImage();
								nxtframe.setIconImage(top);
								nxtframe.setTitle(maestros[llevar].getNombre());
								dispose();
							}
						});
						btnP1.setBounds(166, 158, 258, 23);
						contentPane.add(btnP1);
						repaint();
						revalidate();
						break;
					case 2:
						btnP1 = new JButton(maestros[p1].getNombre());
						final int llevar2 = p1;
						btnP1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Visualizacion nxtframe = new Visualizacion(0,llevar2);
								nxtframe.setLocationRelativeTo(null);
								nxtframe.setVisible(true);
								String direccion = "/logo.jpg";
								URL url = this.getClass().getResource(direccion);
								ImageIcon icono = new ImageIcon(url);
								Image top = icono.getImage();
								nxtframe.setIconImage(top);
								nxtframe.setTitle(maestros[llevar2].getNombre());
								dispose();
							}
						});
						btnP1.setBounds(166, 158, 258, 23);
						contentPane.add(btnP1);
						JButton btnP2 = new JButton(maestros[p2].getNombre());
						final int llevar3 = p2;
						btnP2.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Visualizacion nxtframe = new Visualizacion(0,llevar3);
								nxtframe.setLocationRelativeTo(null);
								nxtframe.setVisible(true);
								String direccion = "/logo.jpg";
								URL url = this.getClass().getResource(direccion);
								ImageIcon icono = new ImageIcon(url);
								Image top = icono.getImage();
								nxtframe.setIconImage(top);
								nxtframe.setTitle(maestros[llevar3].getNombre());
								dispose();
							}
						});
						btnP2.setBounds(166, 192, 258, 23);
						contentPane.add(btnP2);
						repaint();
						break;
					case 3: 
						btnP1 = new JButton(maestros[p1].getNombre());
						final int llevar4 = p1;
						btnP1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Visualizacion nxtframe = new Visualizacion(0,llevar4);
								nxtframe.setLocationRelativeTo(null);
								nxtframe.setVisible(true);
								String direccion = "/logo.jpg";
								URL url = this.getClass().getResource(direccion);
								ImageIcon icono = new ImageIcon(url);
								Image top = icono.getImage();
								nxtframe.setIconImage(top);
								nxtframe.setTitle(maestros[llevar4].getNombre());
								dispose();
							}
						});
						btnP1.setBounds(166, 158, 258, 23);
						contentPane.add(btnP1);
						btnP2 = new JButton(maestros[p2].getNombre());
						final int llevar5 = p2;
						btnP2.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Visualizacion nxtframe = new Visualizacion(0,llevar5);
								nxtframe.setLocationRelativeTo(null);
								nxtframe.setVisible(true);
								String direccion = "/logo.jpg";
								URL url = this.getClass().getResource(direccion);
								ImageIcon icono = new ImageIcon(url);
								Image top = icono.getImage();
								nxtframe.setIconImage(top);
								nxtframe.setTitle(maestros[llevar5].getNombre());
								dispose();
							}
						});
						btnP2.setBounds(166, 192, 258, 23);
						contentPane.add(btnP2);
						
						JButton btnP3 = new JButton(maestros[p3].getNombre());
						final int llevar6 = p3;
						btnP3.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Visualizacion nxtframe = new Visualizacion(0,llevar6);
								nxtframe.setLocationRelativeTo(null);
								nxtframe.setVisible(true);
								String direccion = "/logo.jpg";
								URL url = this.getClass().getResource(direccion);
								ImageIcon icono = new ImageIcon(url);
								Image top = icono.getImage();
								nxtframe.setIconImage(top);
								nxtframe.setTitle(maestros[llevar6].getNombre());
								dispose();
							}
						});
						btnP3.setBounds(166, 227, 258, 23);
						contentPane.add(btnP3);
						repaint();
						break;
					default: break;
				}
			}
			
	    }}
	
	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default:break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     }
		        // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					buscadorVisualizador frame = new buscadorVisualizador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public buscadorVisualizador() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		JLabel lblBuscadorDeHorario = new JLabel("Buscador de Horario");
		lblBuscadorDeHorario.setForeground(Color.BLUE);
		lblBuscadorDeHorario.setFont(new Font("Times New Roman", Font.BOLD, 21));
		lblBuscadorDeHorario.setBounds(125, 11 , 194, 30);
		contentPane.add(lblBuscadorDeHorario);
		
		txtMaestro = new JTextField();
		txtMaestro.setBounds(99, 42, 325, 21);
		contentPane.add(txtMaestro);
		txtMaestro.setColumns(10);
		txtMaestro.setToolTipText("Ingrese el nombre de un maestro");
		
		JButton btnbuscar = new JButton("Buscar");
		btnbuscar.setForeground(Color.BLUE);
		btnbuscar.setBounds(10, 42, 89, 20);
		contentPane.add(btnbuscar);
		btnbuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				(new buscar()).start();
				}
		});
		
		int o = 0;
		for(int x = 0; x < 100; x++){
			if(maestros[x].getNombre() != " " && maestros[x].getNombre().length() >= 2){ 
				o++;
			}}
		int d = 0;
		String[] maestroses = new String[o];
		for(int x = 0; x <100; x++){
			if(maestros[x].getNombre() != " "  && maestros[x].getNombre().length() >= 2){
			maestroses[d] = maestros[x].getNombre();
			d++;}
		}
		 String temp="";
		  for (int m=0; m<maestroses.length-1; m++)
		    for (int n=0; n<maestroses.length-1; n++){
		    if (maestroses[n].compareTo(maestroses[n+1]) > 0){
		    temp=maestroses[n+1];
		    maestroses[n+1]=maestroses[n];
		    maestroses[n]=temp;}
		    else if(maestroses[n].compareTo(maestroses[n+1]) == 0){
		    	if (maestroses[n].substring(1).compareTo(maestroses[n+1].substring(1)) > 0){
				    temp=maestroses[n+1];
				    maestroses[n+1]=maestroses[n];
				    maestroses[n]=temp;}
		    }}
		JComboBox comboBox = new JComboBox(maestroses);
		comboBox.setSelectedIndex(0);
		comboBox.setForeground(Color.BLUE);
		comboBox.setBounds(10, 76, 414, 20);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int esta = -1;
				for(int x = 0; x < maestros.length; x++){
				     if (maestros[x].getNombre() == (String)comboBox.getSelectedItem()){
				         esta = x; x = maestros.length;}
				}
				Visualizacion nxtframe = new Visualizacion(0,esta);
				nxtframe.setLocationRelativeTo(null);
				nxtframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				nxtframe.setTitle(maestros[esta].getNombre());
				dispose();
				
			}
		});
		contentPane.add(comboBox);
		
		JButton btnAtrs = new JButton("atr\u00E1s");
		btnAtrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu pstframe = new Menu();
				pstframe.setTitle("Menu Principal");
				pstframe.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				pstframe.setIconImage(top);
				pstframe.setVisible(true);
				dispose();
			}
		});
		btnAtrs.setBounds(0, 0, 89, 23);
		contentPane.add(btnAtrs);
	}
}
