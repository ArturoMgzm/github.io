package program;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.StringTokenizer;
import java.awt.event.ActionEvent;

public class OpcionesGestionar extends JFrame {

	private JPanel contentPane;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OpcionesGestionar frame = new OpcionesGestionar();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default:break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     }
		         // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	/**
	 * Create the frame.
	 */
	public OpcionesGestionar() {
		setResizable(false);
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		 int z = 0;
		 for(int a = 0; a<maestros.length;a++){
			   if(maestros[a].getNombre().equals (" ")){
			   z = a;
			   a=maestros.length;}}
		final int zz = z;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 395, 297);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblGH = new JLabel("Gestionar Horario");
		lblGH.setForeground(Color.BLUE);
		lblGH.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblGH.setBounds(116, 11, 216, 27);
		contentPane.add(lblGH);
		
		JButton btnElH = new JButton("Eliminar Horario");
		btnElH.setForeground(Color.BLUE);
		btnElH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BuscadorEliminador nxtframe = new BuscadorEliminador();
				nxtframe.setTitle("Seleccionar para eliminar");
				nxtframe.setLocationRelativeTo(null);
				nxtframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				dispose();
			}
		});
		btnElH.setFont(new Font("Arial", Font.PLAIN, 16));
		btnElH.setPreferredSize(new Dimension(117, 26));
		btnElH.setBounds(10, 157, 179, 101);
		contentPane.add(btnElH);
		
		JButton btnCH = new JButton("Crear Horario");
		btnCH.setForeground(Color.BLUE);
		btnCH.setFont(new Font("Arial", Font.PLAIN, 16));
		btnCH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreadorH nxtframe = new CreadorH(0,"","",zz);
				nxtframe.setTitle("Proceso de Creacion de Horario");
				nxtframe.setLocationRelativeTo(null);
				nxtframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				dispose();
			}
		});
		btnCH.setBounds(10, 52, 179, 97);
		contentPane.add(btnCH);
		
		JButton btnEh = new JButton("Editar Horario");
		btnEh.setForeground(Color.BLUE);
		btnEh.setFont(new Font("Arial", Font.PLAIN, 16));
		btnEh.setBounds(199, 52, 179, 97);
		contentPane.add(btnEh);
		btnEh.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		BuscadorEditar nxtframe = new BuscadorEditar();
		nxtframe.setTitle("Seleccionar para editar");
		nxtframe.setLocationRelativeTo(null);
		nxtframe.setVisible(true);
		String direccion = "/logo.jpg";
		URL url = this.getClass().getResource(direccion);
		ImageIcon icono = new ImageIcon(url);
		Image top = icono.getImage();
		nxtframe.setIconImage(top);
		dispose();}
	});
		
		JButton btnAtras = new JButton("Atr�s");
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu pstframe = new Menu();
				pstframe.setTitle("Menu Principal");
				pstframe.setLocationRelativeTo(null);
				pstframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				pstframe.setIconImage(top);
				dispose();
			}
		});
		btnAtras.setBounds(0, 0, 89, 23);
		contentPane.add(btnAtras);
	}

}
