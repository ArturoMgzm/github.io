package program;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.StringTokenizer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.print.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class EsteImprimir extends JFrame implements Printable, ActionListener {

	private JFrame frameToPrint;
	private JPanel contentPane;
	private JTextField textField_30;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];

	/**
	 * Launch the application.
	 */
	
	public static Dimension getScaledDimension(Dimension imgSize, Dimension boundary) {

	    int original_width = imgSize.width;
	    int original_height = imgSize.height;
	    int bound_width = boundary.width;
	    int bound_height = boundary.height;
	    int new_width = original_width;
	    int new_height = original_height;

	    // first check if we need to scale width
	    if (original_width > bound_width) {
	        //scale width to fit
	        new_width = bound_width;
	        //scale height to maintain aspect ratio
	        new_height = (new_width * original_height) / original_width;
	    }

	    // then check if we need to scale even with the new height
	    if (new_height > bound_height) {
	        //scale height to fit instead
	        new_height = bound_height;
	        //scale width to maintain aspect ratio
	        new_width = (new_height * original_width) / original_height;
	    }

	    return new Dimension(new_width, new_height);
	}
	
	 public void actionPerformed(ActionEvent e) {
         PrinterJob job = PrinterJob.getPrinterJob();
         job.setPrintable(this);
         boolean ok = job.printDialog();
         if (ok) {
             try {
                  job.print();
             } catch (PrinterException ex) {
             }
         }
    }
	
	 public int print(Graphics g, PageFormat pf, int page) throws
     PrinterException {

if (page > 0) {
return NO_SUCH_PAGE;
}
Graphics2D g2d = (Graphics2D)g;
g2d.translate(pf.getImageableX(), pf.getImageableY());
frameToPrint.printAll(g);
return PAGE_EXISTS;
}
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EsteImprimir frame = new EsteImprimir(0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default: break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     } // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	public static void actualizar(Maestro maestros[], int e){
	maestros[e].setNombre(" ");
	for(int d = 0; d < 5; d++){
		for(int h = 0; h < 10; h++){
			maestros[e].setClase(" ", h, d);
			maestros[e].setGrupo(" ", h, d);
			maestros[e].setSalon(" ", h, d);
		}
	}
	}
	
	 public static void guardar(Maestro maestros[]) throws IOException{
		   fileOut=new PrintWriter(new FileWriter("\\Users\\Arturo\\Documents\\Informatica 2 BI\\Eclipse\\Horarios.txt"));
		   String linea = "";
		   for(int y = 0; y<maestros.length;y++){
			   fileOut.println(maestros[y].getNombre() + "/");
		for(int dia = 0; dia<5;dia++){
		   for(int x = 0; x<10;x++){
			   switch(dia){
				   case 0: linea = "L" + maestros[y].getClase(x, dia) + "/L" + maestros[y].getSalon(x, dia) + "/L" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 1: linea = "M" + maestros[y].getClase(x, dia) + "/M" + maestros[y].getSalon(x, dia) + "/M" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 2: linea = "I" + maestros[y].getClase(x, dia) + "/I" + maestros[y].getSalon(x, dia) + "/I" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 3: linea = "J" + maestros[y].getClase(x, dia) + "/J" + maestros[y].getSalon(x, dia) + "/J" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 4: linea = "V" + maestros[y].getClase(x, dia) + "/V" + maestros[y].getSalon(x, dia) + "/V" + maestros[y].getGrupo(x, dia) + "/"; break;
				   default:break;}
			   
		   fileOut.println(linea);
	 }}}
		 fileOut.close();
		 }
	 
	    public EsteImprimir(JFrame f) {
	        frameToPrint = f;
	    }
	
	
	/**
	 * @wbp.parser.constructor
	 */
	public EsteImprimir(int este) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 601, 313);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		JLabel lblNewLabel = new JLabel("�Como desea imprimir este horario?");
		lblNewLabel.setForeground(new Color(0, 0, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel.setBounds(209, 11, 376, 29);
		contentPane.add(lblNewLabel);
		
		JButton ok = new JButton("Clases");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Visualizacion f = new Visualizacion(0,este);
				f.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				f.setIconImage(top);
				
				ok.addActionListener(new EsteImprimir(f));
			}
		});
		ok.setBounds(327, 63, 140, 34);
		contentPane.add(ok);
		
		JLabel lblWarning = new JLabel("");
		lblWarning.setForeground(Color.YELLOW);
		lblWarning.setBackground(Color.YELLOW);
		lblWarning.setBounds(88, 101, 121, 139);
		ImageIcon photo=new ImageIcon("\\Users\\" + System.getProperty("user.name") + "\\Documents\\HorariosTecImages\\" + maestros[este].getNombre() + ".jpg");
		Dimension imgSize = new Dimension(photo.getIconWidth(), photo.getIconHeight());
		Dimension boundary = new Dimension(121, 139);
		Dimension trueDimension = getScaledDimension(imgSize,boundary);
		Image scalephoto = photo.getImage().getScaledInstance((int)trueDimension.getWidth(),(int)trueDimension.getHeight(),Image.SCALE_SMOOTH);
		photo = new ImageIcon(scalephoto);
		lblWarning.setIcon(photo);
		contentPane.add(lblWarning);
		
		JButton cancl = new JButton("Cancelar");
		cancl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu pstframe = new Menu();
				pstframe.setTitle("Menu principal");
				pstframe.setLocationRelativeTo(null);
				pstframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				pstframe.setIconImage(top);
				dispose();
			}
		});
		cancl.setBounds(327, 229, 140, 34);
		contentPane.add(cancl);
		
		JLabel lblNewLabel_2 = new JLabel(maestros[este].getNombre());
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.ITALIC, 18));
		lblNewLabel_2.setBounds(10, 66, 277, 24);
		contentPane.add(lblNewLabel_2);
		
		JButton button = new JButton("Salones");
		button.setBounds(327, 103, 140, 34);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Visualizacion f = new Visualizacion(1,este);
				f.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				f.setIconImage(top);
				
				button.addActionListener(new EsteImprimir(f));
			}
		});

		contentPane.add(button);
		
		
		JButton button_1 = new JButton("Grupos");
		button_1.setBounds(327, 148, 140, 34);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Visualizacion f = new Visualizacion(2,este);
				f.setLocationRelativeTo(null);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				f.setIconImage(top);
				button_1.addActionListener(new EsteImprimir(f));
			}
		});
		contentPane.add(button_1);
		
	}
}
