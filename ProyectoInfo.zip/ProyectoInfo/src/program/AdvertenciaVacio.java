package program;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.StringTokenizer;
import java.awt.event.ActionEvent;


public class AdvertenciaVacio extends JFrame {

	private JPanel contentPane;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];
	/**
	 * 
	 * Launch the application.
	 */
	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default:break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     }
		         // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	 public static void guardar(Maestro maestros[]) throws IOException{
		   fileOut=new PrintWriter(new FileWriter("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		   String linea = "";
		   for(int y = 0; y<maestros.length;y++){
			   fileOut.println(maestros[y].getNombre() + "/");
		for(int dia = 0; dia<5;dia++){
		   for(int x = 0; x<10;x++){
			   switch(dia){
				   case 0: linea = "L" + maestros[y].getClase(x, dia) + "/L" + maestros[y].getSalon(x, dia) + "/L" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 1: linea = "M" + maestros[y].getClase(x, dia) + "/M" + maestros[y].getSalon(x, dia) + "/M" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 2: linea = "I" + maestros[y].getClase(x, dia) + "/I" + maestros[y].getSalon(x, dia) + "/I" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 3: linea = "J" + maestros[y].getClase(x, dia) + "/J" + maestros[y].getSalon(x, dia) + "/J" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 4: linea = "V" + maestros[y].getClase(x, dia) + "/V" + maestros[y].getSalon(x, dia) + "/V" + maestros[y].getGrupo(x, dia) + "/"; break;
				   default:break;}
			   
		   fileOut.println(linea);
	 }}}
		 fileOut.close();
		 }
	
	 public static void actualizar(Maestro[] maestros,int vaciar){
		 maestros[vaciar].setNombre(" ");
		for (int dia = 0; dia<5;dia++){ 
		for(int y = 0; y<10;y++){
			maestros[vaciar].setClase(" ", y, dia);
			maestros[vaciar].setSalon(" ", y, dia);
			maestros[vaciar].setGrupo(" ", y, dia);
		}
		}
			 }
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdvertenciaVacio frame = new AdvertenciaVacio(0,50);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdvertenciaVacio(int error, int vaciar) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		 int z = -1;
		 for(int a = 0; a<maestros.length;a++){
			   if(maestros[a].getNombre().equals (" ")){
			   z = a;
			   a=maestros.length;}}
		final int zz = z;

		if(error == 0){
			setBounds(100, 100, 450, 150);

			JLabel lblNewLabel = new JLabel("El horario no esta asignado a un nombre �Desea salir sin guardar?");
			lblNewLabel.setForeground(new Color(0, 0, 255));
			lblNewLabel.setFont(new Font("Times New Roman", Font.ITALIC, 14));
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(10, 11, 414, 30);
			contentPane.add(lblNewLabel);
			
			JButton btnNewButton = new JButton("Ok");
			btnNewButton.setBounds(49, 52, 145, 45);
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					actualizar(maestros,vaciar);
					try {
						guardar(maestros);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println("hola");
						e.printStackTrace();
					}
					java.awt.Window win[] = java.awt.Window.getWindows(); 
					for(int i=0;i<win.length;i++){ 
					win[i].dispose(); 
					} 
					Menu nxtframe = new Menu();
					nxtframe.setTitle("Menu Principal");
					nxtframe.setLocationRelativeTo(null);
					String direccion = "/logo.jpg";
					URL url = this.getClass().getResource(direccion);
					ImageIcon icono = new ImageIcon(url);
					Image top = icono.getImage();
					nxtframe.setIconImage(top);
					nxtframe.setVisible(true);
				}
			});
			
			contentPane.add(btnNewButton);
			
			JButton button = new JButton("Cancelar");
			button.setBounds(239, 52, 145, 45);
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			contentPane.add(button);
			repaint();
		}
		if(error == 1){
			setBounds(100, 100, 450, 150);

			JLabel lblNewLabel = new JLabel("El horario no esta asignado a un nombre �Desea eliminar el horario?");
			lblNewLabel.setForeground(new Color(0, 0, 255));
			lblNewLabel.setFont(new Font("Times New Roman", Font.ITALIC, 14));
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(10, 11, 414, 30);
			contentPane.add(lblNewLabel);
			
			JButton btnNewButton = new JButton("Ok");
			btnNewButton.setBounds(49, 52, 145, 45);
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					actualizar(maestros,vaciar);
					try {
						guardar(maestros);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println("hola");
						e.printStackTrace();
					}
					java.awt.Window win[] = java.awt.Window.getWindows(); 
					for(int i=0;i<win.length;i++){ 
					win[i].dispose(); 
					} 
					Menu nxtframe = new Menu();
					nxtframe.setTitle("Menu Principal");
					nxtframe.setLocationRelativeTo(null);
					String direccion = "/logo.jpg";
					URL url = this.getClass().getResource(direccion);
					ImageIcon icono = new ImageIcon(url);
					Image top = icono.getImage();
					nxtframe.setIconImage(top);
					nxtframe.setVisible(true);
				}
			});
			
			contentPane.add(btnNewButton);
			
			JButton button = new JButton("Cancelar");
			button.setBounds(239, 52, 145, 45);
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			contentPane.add(button);
			repaint();
		}
		
	}
}
