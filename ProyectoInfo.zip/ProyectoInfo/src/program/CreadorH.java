package program;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.image.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.URL;
import java.util.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class CreadorH extends JFrame {

	private JPanel contentPane;
	private JTextField C0;
	private JTextField C1;
	private JTextField C2;
	private JTextField C3;
	private JTextField C4;
	private JTextField C5;
	private JTextField C6;
	private JTextField C7;
	private JTextField C8;
	private JTextField C9;
	private JTextField S0;
	private JTextField S1;
	private JTextField S2;
	private JTextField S3;
	private JTextField S4;
	private JTextField S5;
	private JTextField S6;
	private JTextField S7;
	private JTextField S8;
	private JTextField S9;
	private JTextField G0;
	private JTextField G1;
	private JTextField G2;
	private JTextField G3;
	private JTextField G4;
	private JTextField G5;
	private JTextField G6;
	private JTextField G7;
	private JTextField G8;
	private JTextField G9;
	private JTextField textField_30;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];
	private JTextField textUrl;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws IOException{
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreadorH frame = new CreadorH(0, "", "",0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default:break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     }
		         // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	 public static void guardar(Maestro maestros[]) throws IOException{
		 
		   File file = new File("/Users/" + System.getProperty("user.name") + "/Documents/Horarios");
	        if (!file.exists()) {
	        	file.mkdir();
	        }
		 
		   fileOut=new PrintWriter(new FileWriter("/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		   String linea = "";
		   for(int y = 0; y<maestros.length;y++){
			   fileOut.println(maestros[y].getNombre() + "/");
		for(int dia = 0; dia<5;dia++){
		   for(int x = 0; x<10;x++){
			   switch(dia){
				   case 0: linea = "L" + maestros[y].getClase(x, dia) + "/L" + maestros[y].getSalon(x, dia) + "/L" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 1: linea = "M" + maestros[y].getClase(x, dia) + "/M" + maestros[y].getSalon(x, dia) + "/M" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 2: linea = "I" + maestros[y].getClase(x, dia) + "/I" + maestros[y].getSalon(x, dia) + "/I" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 3: linea = "J" + maestros[y].getClase(x, dia) + "/J" + maestros[y].getSalon(x, dia) + "/J" + maestros[y].getGrupo(x, dia) + "/"; break;
				   case 4: linea = "V" + maestros[y].getClase(x, dia) + "/V" + maestros[y].getSalon(x, dia) + "/V" + maestros[y].getGrupo(x, dia) + "/"; break;
				   default:break;}
			   
		   fileOut.println(linea);
	 }}}
		 fileOut.close();
		 }
	
	 public static void actualizar(Maestro[] maestros, String c[], String s[], String g[], String nombre, int dia, int nuevo){
		 maestros[nuevo].setNombre(nombre);
		for(int y = 0; y<10;y++){
			maestros[nuevo].setClase(c[y], y, dia);
			maestros[nuevo].setSalon(s[y], y, dia);
			maestros[nuevo].setGrupo(g[y], y, dia);
		}
			 }
	 
	public CreadorH(int x, String n, String u, int nuevo) {
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 448, 587);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final int d = x;
		JButton btnAtrs = new JButton("Atr\u00E1s");
		btnAtrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField_30.getText().isEmpty()){
					//contentPane.showMessageDialog(JFrame,"Es necesario introducir un nombre al horario.");
					AdvertenciaVacio wrngframe = new AdvertenciaVacio(0,nuevo);
					wrngframe.setTitle("�Advertencia!");
					wrngframe.setLocationRelativeTo(null);
					String direccion = "/logo.jpg";
					URL url = this.getClass().getResource(direccion);
					ImageIcon icono = new ImageIcon(url);
					Image top = icono.getImage();
					wrngframe.setIconImage(top);
					wrngframe.setVisible(true);
				} 
				else{
					
					String StrNombre = textField_30.getText();
					String StrS0 = S0.getText(),StrS1 = S1.getText(),StrS2 = S2.getText(),StrS3 = S3.getText(),StrS4 = S4.getText(),StrS5 = S5.getText(),StrS6 = S6.getText(),StrS7 = S7.getText(),StrS8 = S8.getText(),StrS9 = S9.getText();
					String StrG0 = G0.getText(),StrG1 = G1.getText(),StrG2 = G2.getText(),StrG3 = G3.getText(),StrG4 = G4.getText(),StrG5 = G5.getText(),StrG6 = G6.getText(),StrG7 = G7.getText(),StrG8 = G8.getText(),StrG9 = G9.getText();
					String StrC0 = C0.getText(),StrC1 = C1.getText(),StrC2 = C2.getText(),StrC3 = C3.getText(),StrC4 = C4.getText(),StrC5 = C5.getText(),StrC6 = C6.getText(),StrC7 = C7.getText(),StrC8 = C8.getText(),StrC9 = C9.getText();
					String[] s = {StrS0,StrS1,StrS2,StrS3,StrS4,StrS5,StrS6,StrS7,StrS8,StrS9};
					String[] c = {StrC0,StrC1,StrC2,StrC3,StrC4,StrC5,StrC6,StrC7,StrC8,StrC9};
					String[] g = {StrG0,StrG1,StrG2,StrG3,StrG4,StrG5,StrG6,StrG7,StrG8,StrG9};
					for(int y = 0; y < 10; y++){
						if(s[y].equals(" ")){s[y] = "-";}
						if(c[y].equals(" ")){c[y] = "-";}
						if(g[y].equals(" ")){g[y] = "-";}
					}
					String StrUrl = textUrl.getText();
					actualizar(maestros,c,s,g,StrNombre,d,nuevo);
					if (textUrl.getText().isEmpty() == false){
					try {
						MyImage.Myimage(StrNombre, StrUrl);
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}}
					try {
						guardar(maestros);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
				OpcionesGestionar pstframe = new OpcionesGestionar();
				pstframe.setLocationRelativeTo(null);
				pstframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				pstframe.setIconImage(top);
				dispose();
			}
				}
		});
		btnAtrs.setBounds(0, 0, 89, 23);
		contentPane.add(btnAtrs);
	
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(new Color(255, 255, 255));
		lblNombre.setBackground(new Color(128, 128, 128));
		lblNombre.setOpaque(true);
		lblNombre.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombre.setBounds(144, 44, 89, 23);
		contentPane.add(lblNombre);
		String direccion = "/TEC.png";
		URL url = this.getClass().getResource(direccion);
		ImageIcon icono=new ImageIcon(url);
		
		String[] dias = {"Lunes","Martes","Mi�rcoles", "Jueves","Viernes"};
		JComboBox boxDias = new JComboBox(dias);
		boxDias.setFont(new Font("Tahoma", Font.PLAIN, 15));
		boxDias.setSelectedIndex(x);
		boxDias.setBounds(290, 93, 134, 23);
		boxDias.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int day = -1;
				String opcion = (String)boxDias.getSelectedItem();
				switch (opcion){
				case "Lunes": day = 0; break;
				case "Martes": day = 1;break;
				case "Mi�rcoles": day = 2;break;
				case "Jueves": day = 3;break;
				case "Viernes": day= 4;break;
				default:break;
				}
				String StrNombre = textField_30.getText();
				String StrS0 = S0.getText(),StrS1 = S1.getText(),StrS2 = S2.getText(),StrS3 = S3.getText(),StrS4 = S4.getText(),StrS5 = S5.getText(),StrS6 = S6.getText(),StrS7 = S7.getText(),StrS8 = S8.getText(),StrS9 = S9.getText();
				String StrG0 = G0.getText(),StrG1 = G1.getText(),StrG2 = G2.getText(),StrG3 = G3.getText(),StrG4 = G4.getText(),StrG5 = G5.getText(),StrG6 = G6.getText(),StrG7 = G7.getText(),StrG8 = G8.getText(),StrG9 = G9.getText();
				String StrC0 = C0.getText(),StrC1 = C1.getText(),StrC2 = C2.getText(),StrC3 = C3.getText(),StrC4 = C4.getText(),StrC5 = C5.getText(),StrC6 = C6.getText(),StrC7 = C7.getText(),StrC8 = C8.getText(),StrC9 = C9.getText();
				String[] s = {StrS0,StrS1,StrS2,StrS3,StrS4,StrS5,StrS6,StrS7,StrS8,StrS9};
				String[] c = {StrC0,StrC1,StrC2,StrC3,StrC4,StrC5,StrC6,StrC7,StrC8,StrC9};
				String[] g = {StrG0,StrG1,StrG2,StrG3,StrG4,StrG5,StrG6,StrG7,StrG8,StrG9};
				for(int y = 0; y < 10; y++){
					if(s[y].equals(" ")){s[y] = "-";}
					if(c[y].equals(" ")){c[y] = "-";}
					if(g[y].equals(" ")){g[y] = "-";}
				}
				String StrUrl = textUrl.getText();
				actualizar(maestros,c,s,g,StrNombre,d,nuevo);
				if (textUrl.getText().isEmpty() == false){
				try {
					MyImage.Myimage(StrNombre, StrUrl);
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}}
				try {
					guardar(maestros);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				CreadorH nxtframe = new CreadorH(day, StrNombre, StrUrl, nuevo);
				nxtframe.setTitle("Proceso de Creacion de Horario");
				nxtframe.setLocationRelativeTo(null);
				nxtframe.setVisible(true);
				String direccion = "/logo.jpg";
				URL url = this.getClass().getResource(direccion);
				ImageIcon icono = new ImageIcon(url);
				Image top = icono.getImage();
				nxtframe.setIconImage(top);
				dispose();
			}
		});
		contentPane.add(boxDias);
		
		
		JLabel lblHora = new JLabel("Hora");
		lblHora.setForeground(new Color(255, 255, 255));
		lblHora.setBackground(new Color(128, 128, 128));
		lblHora.setOpaque(true);
		lblHora.setHorizontalAlignment(SwingConstants.CENTER);
		lblHora.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblHora.setSize(new Dimension(100, 30));
		lblHora.setPreferredSize(new Dimension(187, 14));
		lblHora.setBounds(12, 192, 103, 30);
		contentPane.add(lblHora);
		
		JLabel lbl_Lunes = new JLabel("Clase");
		lbl_Lunes.setSize(new Dimension(100, 30));
		lbl_Lunes.setPreferredSize(new Dimension(187, 14));
		lbl_Lunes.setOpaque(true);
		lbl_Lunes.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Lunes.setForeground(Color.WHITE);
		lbl_Lunes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Lunes.setBackground(Color.GRAY);
		lbl_Lunes.setBounds(117, 192, 103, 30);
		contentPane.add(lbl_Lunes);
		
		JLabel lbl_Martes= new JLabel("Salon");
		lbl_Martes.setLocation(new Point(230, 190));
		lbl_Martes.setSize(new Dimension(100, 30));
		lbl_Martes.setPreferredSize(new Dimension(187, 14));
		lbl_Martes.setOpaque(true);
		lbl_Martes.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Martes.setForeground(Color.WHITE);
		lbl_Martes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Martes.setBackground(Color.GRAY);
		lbl_Martes.setBounds(218, 192, 103, 30);
		contentPane.add(lbl_Martes);
		
		JLabel lbl_Miercoles = new JLabel("Grupo");
		lbl_Miercoles.setSize(new Dimension(100, 30));
		lbl_Miercoles.setPreferredSize(new Dimension(187, 14));
		lbl_Miercoles.setOpaque(true);
		lbl_Miercoles.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Miercoles.setForeground(Color.WHITE);
		lbl_Miercoles.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Miercoles.setBackground(Color.GRAY);
		lbl_Miercoles.setBounds(321, 192, 103, 30);
		contentPane.add(lbl_Miercoles);
		
		JLabel label_1 = new JLabel("7:20-8:30");
		label_1.setSize(new Dimension(100, 30));
		label_1.setPreferredSize(new Dimension(187, 14));
		label_1.setOpaque(true);
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_1.setBackground(new Color(220, 220, 220));
		label_1.setBounds(12, 227, 103, 30);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("8:30-9:30");
		label_2.setSize(new Dimension(100, 30));
		label_2.setPreferredSize(new Dimension(187, 14));
		label_2.setOpaque(true);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_2.setBackground(new Color(192, 192, 192));
		label_2.setBounds(12, 256, 103, 30);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("9:30-10:30");
		label_3.setSize(new Dimension(100, 30));
		label_3.setPreferredSize(new Dimension(187, 14));
		label_3.setOpaque(true);
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_3.setBackground(new Color(220, 220, 220));
		label_3.setBounds(12, 283, 103, 30);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("10:30-11:30");
		label_4.setSize(new Dimension(100, 30));
		label_4.setPreferredSize(new Dimension(187, 14));
		label_4.setOpaque(true);
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_4.setBackground(new Color(192, 192, 192));
		label_4.setBounds(12, 313, 103, 30);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("11:30-12:30");
		label_5.setSize(new Dimension(100, 30));
		label_5.setPreferredSize(new Dimension(187, 14));
		label_5.setOpaque(true);
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_5.setBackground(new Color(220, 220, 220));
		label_5.setBounds(12, 341, 103, 30);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("12:30-1:30");
		label_6.setSize(new Dimension(100, 30));
		label_6.setPreferredSize(new Dimension(187, 14));
		label_6.setOpaque(true);
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_6.setBackground(new Color(192, 192, 192));
		label_6.setBounds(12, 370, 103, 30);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("1:30-2:30");
		label_7.setSize(new Dimension(100, 30));
		label_7.setPreferredSize(new Dimension(187, 14));
		label_7.setOpaque(true);
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_7.setBackground(new Color(220, 220, 220));
		label_7.setBounds(12, 398, 103, 30);
		contentPane.add(label_7);
		
		JLabel label_8 = new JLabel("2:30-3:30");
		label_8.setSize(new Dimension(100, 30));
		label_8.setPreferredSize(new Dimension(187, 14));
		label_8.setOpaque(true);
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_8.setBackground(new Color(192, 192, 192));
		label_8.setBounds(12, 428, 103, 30);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel("3:30-4:30");
		label_9.setSize(new Dimension(100, 30));
		label_9.setPreferredSize(new Dimension(187, 14));
		label_9.setOpaque(true);
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_9.setBackground(new Color(220, 220, 220));
		label_9.setBounds(12, 456, 103, 30);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("4:30-5:30");
		label_10.setSize(new Dimension(100, 30));
		label_10.setPreferredSize(new Dimension(187, 14));
		label_10.setOpaque(true);
		label_10.setHorizontalAlignment(SwingConstants.CENTER);
		label_10.setForeground(Color.WHITE);
		label_10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_10.setBackground(new Color(192, 192, 192));
		label_10.setBounds(12, 481, 103, 30);
		contentPane.add(label_10);
		
		C0 = new JTextField(maestros[nuevo].getClase(0, d));
		C0.setHorizontalAlignment(SwingConstants.LEFT);
		C0.setBounds(117, 228, 103, 30);
		contentPane.add(C0);
		C0.setColumns(10);
		
		C1 = new JTextField(maestros[nuevo].getClase(1, d));
		C1.setColumns(10);
		C1.setBounds(117, 256, 103, 30);
		contentPane.add(C1);
		
		C2 = new JTextField(maestros[nuevo].getClase(2, d));
		C2.setColumns(10);
		C2.setBounds(117, 283, 103, 30);
		contentPane.add(C2);
		
		C3 = new JTextField(maestros[nuevo].getClase(3, d));
		C3.setColumns(10);
		C3.setBounds(117, 313, 103, 30);
		contentPane.add(C3);
		
		C4 = new JTextField(maestros[nuevo].getClase(4, d));
		C4.setColumns(10);
		C4.setBounds(117, 341, 103, 30);
		contentPane.add(C4);
		
		C5 = new JTextField(maestros[nuevo].getClase(5, d));
		C5.setColumns(10);
		C5.setBounds(117, 370, 103, 30);
		contentPane.add(C5);
		
		C6 = new JTextField(maestros[nuevo].getClase(6, d));
		C6.setColumns(10);
		C6.setBounds(117, 398, 103, 30);
		contentPane.add(C6);
		
		C7 = new JTextField(maestros[nuevo].getClase(7, d));
		C7.setColumns(10);
		C7.setBounds(117, 428, 103, 30);
		contentPane.add(C7);
		
		C8 = new JTextField(maestros[nuevo].getClase(8, d));
		C8.setColumns(10);
		C8.setBounds(117, 456, 103, 30);
		contentPane.add(C8);
		
		C9 = new JTextField(maestros[nuevo].getClase(9, d));
		C9.setColumns(10);
		C9.setBounds(117, 481, 103, 30);
		contentPane.add(C9);
		
		S0 = new JTextField(maestros[nuevo].getSalon(0, d));
		S0.setColumns(10);
		S0.setBounds(218, 228, 103, 30);
		contentPane.add(S0);
		
		S1 = new JTextField(maestros[nuevo].getSalon(1, d));
		S1.setColumns(10);
		S1.setBounds(218, 256, 103, 30);
		contentPane.add(S1);
		
		S2 = new JTextField(maestros[nuevo].getSalon(2, d));
		S2.setColumns(10);
		S2.setBounds(218, 283, 103, 30);
		contentPane.add(S2);
		
		S3 = new JTextField(maestros[nuevo].getSalon(3, d));
		S3.setColumns(10);
		S3.setBounds(218, 313, 103, 30);
		contentPane.add(S3);
		
		S4 = new JTextField(maestros[nuevo].getSalon(4, d));
		S4.setColumns(10);
		S4.setBounds(218, 341, 103, 30);
		contentPane.add(S4);
		
		S5 = new JTextField(maestros[nuevo].getSalon(5, d));
		S5.setColumns(10);
		S5.setBounds(218, 370, 103, 30);
		contentPane.add(S5);
		
		S6 = new JTextField(maestros[nuevo].getSalon(6, d));
		S6.setColumns(10);
		S6.setBounds(218, 398, 103, 30);
		contentPane.add(S6);
		
		S7 = new JTextField(maestros[nuevo].getSalon(7, d));
		S7.setColumns(10);
		S7.setBounds(218, 428, 103, 30);
		contentPane.add(S7);
		
		S8 = new JTextField(maestros[nuevo].getSalon(8, d));
		S8.setColumns(10);
		S8.setBounds(218, 456, 103, 30);
		contentPane.add(S8);
		
		S9 = new JTextField(maestros[nuevo].getSalon(9, d));
		S9.setColumns(10);
		S9.setBounds(218, 481, 103, 30);
		contentPane.add(S9);
		
		G0 = new JTextField(maestros[nuevo].getGrupo(0, d));
		G0.setColumns(10);
		G0.setBounds(321, 228, 103, 30);
		contentPane.add(G0);
		
		G1 = new JTextField(maestros[nuevo].getGrupo(1, d));
		G1.setColumns(10);
		G1.setBounds(321, 256, 103, 30);
		contentPane.add(G1);
		
		G2 = new JTextField(maestros[nuevo].getGrupo(2, d));
		G2.setColumns(10);
		G2.setBounds(321, 283, 103, 30);
		contentPane.add(G2);
		
		G3 = new JTextField(maestros[nuevo].getGrupo(3, d));
		G3.setColumns(10);
		G3.setBounds(321, 313, 103, 30);
		contentPane.add(G3);
		
		G4 = new JTextField(maestros[nuevo].getGrupo(4, d));
		G4.setColumns(10);
		G4.setBounds(321, 341, 103, 30);
		contentPane.add(G4);
		
		G5 = new JTextField(maestros[nuevo].getGrupo(5, d));
		G5.setColumns(10);
		G5.setBounds(321, 370, 103, 30);
		contentPane.add(G5);
		
		G6 = new JTextField(maestros[nuevo].getGrupo(6, d));
		G6.setColumns(10);
		G6.setBounds(321, 398, 103, 30);
		contentPane.add(G6);
		
		G7 = new JTextField(maestros[nuevo].getGrupo(7, d));
		G7.setColumns(10);
		G7.setBounds(321, 428, 103, 30);
		contentPane.add(G7);
		
		G8 = new JTextField(maestros[nuevo].getGrupo(8, d));
		G8.setColumns(10);
		G8.setBounds(321, 456, 103, 30);
		contentPane.add(G8);
		
		G9 = new JTextField(maestros[nuevo].getGrupo(9, d));
		G9.setColumns(10);
		G9.setBounds(321, 481, 103, 30);
		contentPane.add(G9);
		
		textField_30 = new JTextField(n);
		textField_30.setBounds(232, 44, 192, 23);
		contentPane.add(textField_30);
		textField_30.setColumns(10);
		
		
		textUrl = new JTextField(u);
		textUrl.setToolTipText("Inserte el URL de la imagen");
		textUrl.setBounds(10, 93, 120, 20);
		contentPane.add(textUrl);
		textUrl.setColumns(10);
		
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String StrNombre = textField_30.getText();
				String StrS0 = S0.getText(),StrS1 = S1.getText(),StrS2 = S2.getText(),StrS3 = S3.getText(),StrS4 = S4.getText(),StrS5 = S5.getText(),StrS6 = S6.getText(),StrS7 = S7.getText(),StrS8 = S8.getText(),StrS9 = S9.getText();
				String StrG0 = G0.getText(),StrG1 = G1.getText(),StrG2 = G2.getText(),StrG3 = G3.getText(),StrG4 = G4.getText(),StrG5 = G5.getText(),StrG6 = G6.getText(),StrG7 = G7.getText(),StrG8 = G8.getText(),StrG9 = G9.getText();
				String StrC0 = C0.getText(),StrC1 = C1.getText(),StrC2 = C2.getText(),StrC3 = C3.getText(),StrC4 = C4.getText(),StrC5 = C5.getText(),StrC6 = C6.getText(),StrC7 = C7.getText(),StrC8 = C8.getText(),StrC9 = C9.getText();
				String[] s = {StrS0,StrS1,StrS2,StrS3,StrS4,StrS5,StrS6,StrS7,StrS8,StrS9};
				String[] c = {StrC0,StrC1,StrC2,StrC3,StrC4,StrC5,StrC6,StrC7,StrC8,StrC9};
				String[] g = {StrG0,StrG1,StrG2,StrG3,StrG4,StrG5,StrG6,StrG7,StrG8,StrG9};
				for(int y = 0; y < 10; y++){
					if(s[y].equals(" ")){s[y] = "-";}
					if(c[y].equals(" ")){c[y] = "-";}
					if(g[y].equals(" ")){g[y] = "-";}
				}
				String StrUrl = textUrl.getText();
				actualizar(maestros,c,s,g,StrNombre,d,nuevo);
				if (textUrl.getText().isEmpty() == false){
				try {
					MyImage.Myimage(StrNombre, StrUrl);
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}}
				try {
					guardar(maestros);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});

		btnGuardar.setBounds(10, 522, 414, 23);
		contentPane.add(btnGuardar);
		
		JLabel lblPhoto = new JLabel("photo");
		lblPhoto.setOpaque(true);
		lblPhoto.setBackground(new Color(255, 255, 0));
		lblPhoto.setHorizontalAlignment(SwingConstants.CENTER);
		lblPhoto.setHorizontalTextPosition(SwingConstants.CENTER);
		lblPhoto.setBounds(10, 34, 120, 139);
		contentPane.add(lblPhoto);
		lblPhoto.setIcon(icono);
	}
}
