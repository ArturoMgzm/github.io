package program;

public class Maestro {
	private String nombre;
	private String clasesLunes[ ] = new String[10];
	private String clasesMartes[ ] = new String[10];
	private String clasesMiercoles[ ] = new String[10];
	private String clasesJueves[ ] = new String[10];
	private String clasesViernes[ ] = new String[10];
	private String grupoLunes[ ] = new String[10];
	private String grupoMartes[ ] = new String[10];
	private String grupoMiercoles[ ] = new String[10];
	private String grupoJueves[ ] = new String[10];
	private String grupoViernes[ ] = new String[10];
	private String salonLunes[ ] = new String[10];
	private String salonMartes[ ] = new String[10];
	private String salonMiercoles[ ] = new String[10];
	private String salonJueves[ ] = new String[10];
	private String salonViernes[ ] = new String[10];
	
	public Maestro(){
	this.nombre=" ";
	for(int x = 0; x<10; x++){
		this.clasesLunes[x] = " ";
		this.clasesMartes[x] = " ";
		this.clasesMiercoles[x] = " ";
		this.clasesJueves[x] = " ";
		this.clasesViernes[x] = " ";
		this.salonLunes[x]=" ";
		this.salonMartes[x]=" ";
		this.salonMiercoles[x]=" ";
		this.salonJueves[x]=" ";
		this.salonViernes[x]=" ";
		this.grupoLunes[x]=" ";
		this.grupoMartes[x]=" ";
		this.grupoMiercoles[x]=" ";
		this.grupoJueves[x]=" "; 
		this.grupoViernes[x]=" ";
		
	}
	}
	
	
	 public void setNombre(String n){ //cambiar nombre del objeto 
		    this.nombre=n; }
	 
	 public String getNombre(){
		 return this.nombre;
	 }
	 
	 public String getSalon(int p, int d){ //cambiar nombre del objeto 
		 String c = "";
		 switch (d){
		 case 0: c = this.salonLunes[p];  break;
		 case 1: c = this.salonMartes[p]; break;
		 case 2: c = this.salonMiercoles[p]; break;
		 case 3: c = this.salonJueves[p]; break;
		 case 4: c = this.salonViernes[p]; break;
		 default: break;}
		 return c;
         }
	 
	 public String getGrupo(int p, int d){ //cambiar nombre del objeto 
		 String c = "";
		 switch (d){
		 case 0: c = this.grupoLunes[p];  break;
		 case 1: c = this.grupoMartes[p]; break;
		 case 2: c = this.grupoMiercoles[p]; break;
		 case 3: c = this.grupoJueves[p]; break;
		 case 4: c = this.grupoViernes[p]; break;
		 default: break;}
		 return c;
         }
	 
	 public String getClase(int p, int d){ //cambiar nombre del objeto 
		 String c = "";
		 switch (d){
		 case 0: c = this.clasesLunes[p];  break;
		 case 1: c = this.clasesMartes[p]; break;
		 case 2: c = this.clasesMiercoles[p]; break;
		 case 3: c = this.clasesJueves[p]; break;
		 case 4: c = this.clasesViernes[p]; break;
		 default: break;}
		 return c;
         }
	 
	 public void setClase(String c, int p, int d){ //cambiar nombre del objeto 
		 switch (d){
		 case 0: this.clasesLunes[p]=c;  break;
		 case 1: this.clasesMartes[p]=c; break;
		 case 2: this.clasesMiercoles[p]=c; break;
		 case 3: this.clasesJueves[p]=c; break;
		 case 4: this.clasesViernes[p]=c; break;
		 default: break;
         }}
		 
	 public void setGrupo(String g, int p, int d){ //cambiar nombre del objeto 
			 switch (d){
			 case 0: this.grupoLunes[p]=g;  break;
			 case 1: this.grupoMartes[p]=g; break;
			 case 2: this.grupoMiercoles[p]=g; break;
			 case 3: this.grupoJueves[p]=g; break;
			 case 4: this.grupoViernes[p]=g; break;
			 default: break;
	         }}
			 
	 public void setSalon(String s, int p, int d){ //cambiar nombre del objeto 
				 switch (d){
				 case 0: this.salonLunes[p]=s;  break;
				 case 1: this.salonMartes[p]=s; break;
				 case 2: this.salonMiercoles[p]=s; break;
				 case 3: this.salonJueves[p]=s; break;
				 case 4: this.salonViernes[p]=s; break;
				 default: break;
		         }
		 }
}
