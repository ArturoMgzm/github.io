package program;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class ImprimirHorario extends JFrame {

	private JPanel contentPane;
	private static PrintWriter fileOut;
	private static BufferedReader fileIn;
	public static Maestro[] maestros = new Maestro[100];


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ImprimirHorario frame = new ImprimirHorario(0,0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void recibir(Maestro maestros[ ]) throws IOException{
		 String dato, linea=null; char data;
		 int x = 0, y = 0, z = 0;
		fileIn=new BufferedReader(new FileReader("C:/Users/" + System.getProperty("user.name") + "/Documents/Horarios/Horarios.txt"));
		linea=fileIn.readLine();
		while (linea!=null) // mientras l�nea sea dif. de nulo es que ley� informaci�n
		{ //Separa la l�nea le�da en tokens, indicando que cada tokens esta dividido por un /
		  StringTokenizer tokens= new StringTokenizer(linea,"/");
		  if(z == 0){
		 while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		 {
			    dato=tokens.nextToken();// asigna a dato cada uno de los token 
		        maestros[x].setNombre(dato);
		 }
		        linea=fileIn.readLine();
		        tokens= new StringTokenizer(linea,"/");
		  }
		  while (tokens.hasMoreTokens()) //Regresa true si hay tokens por leer
		  {	
		        	dato = tokens.nextToken();
		        	data = dato.charAt(0);
		        	
		        	switch(data){
		        		case 'L':

		        			maestros[x].setClase(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,0);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,0);
				        	y++;
				        	if(y==10){y=0;}
				        	
		        			break;
		        		case 'M':
		        			maestros[x].setClase(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,1);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,1);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'I':
		        			maestros[x].setClase(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,2);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,2);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'J':
		        			maestros[x].setClase(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,3);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,3);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		case 'V':
		        			maestros[x].setClase(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setSalon(dato.substring(1),y,4);
				        	dato = tokens.nextToken();
				        	maestros[x].setGrupo(dato.substring(1),y,4);
				        	y++;
				        	if(y==10){y=0;
				        }
				        	
		        			break;
		        		default: break;
		        	}
		        	z++;
		        	if (z == 50){z=0;}
		        	
		        if(x != 99 && y == 0 && z == 0)x++;
		        
		        // cuando ya no hay mas tokens de esa l�nea se sale del while
		     }
		         // da un salto de rengl�n
		        linea=fileIn.readLine(); //lee el siguiente registro o l�nea del archivo
	}
		 fileIn.close();// cierra el archivo
		}
	
	public ImprimirHorario( int l, int e) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 648, 550);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		for(int xy = 0; xy<maestros.length;xy++){
			maestros[xy]= new Maestro();
		}
		
		try {
			recibir(maestros);
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		
		JButton btnAtrs = new JButton("Atr\u00E1s");
		btnAtrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				Menu pstframe = new Menu();
				pstframe.setLocationRelativeTo(null);
				pstframe.setVisible(true);
				dispose();
			}
		});
		btnAtrs.setBounds(0, 0, 89, 23);
		contentPane.add(btnAtrs);
	
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(new Color(255, 255, 255));
		lblNombre.setBackground(new Color(128, 128, 128));
		lblNombre.setOpaque(true);
		lblNombre.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombre.setBounds(140, 42, 89, 23);
		contentPane.add(lblNombre);
		
		JLabel label = new JLabel(maestros[e].getNombre());
		label.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		label.setForeground(Color.BLACK);
		label.setOpaque(true);
		label.setBounds(229, 42, 379, 23);
		contentPane.add(label);
		
		JLabel lblPhoto = new JLabel();
		lblPhoto.setBackground(new Color(255, 255, 0));
		lblPhoto.setHorizontalAlignment(SwingConstants.CENTER);
		lblPhoto.setOpaque(true);
		lblPhoto.setHorizontalTextPosition(SwingConstants.CENTER);
		lblPhoto.setBounds(10, 34, 121, 139);
		ImageIcon photo= new ImageIcon("images/"+ maestros[e].getNombre() +".jpg");//poner la referencia a la imagen
		Image scalephoto = photo.getImage().getScaledInstance(121, 139,Image.SCALE_DEFAULT);
		photo = new ImageIcon(scalephoto);
		lblPhoto.setIcon(photo);
		contentPane.add(lblPhoto);
		
		
		JLabel lblHora = new JLabel("Hora");
		lblHora.setForeground(new Color(255, 255, 255));
		lblHora.setBackground(new Color(128, 128, 128));
		lblHora.setOpaque(true);
		lblHora.setHorizontalAlignment(SwingConstants.CENTER);
		lblHora.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblHora.setSize(new Dimension(100, 30));
		lblHora.setPreferredSize(new Dimension(187, 14));
		lblHora.setBounds(12, 192, 103, 30);
		contentPane.add(lblHora);
		
		JLabel lbl_Lunes = new JLabel("Lunes");
		lbl_Lunes.setSize(new Dimension(100, 30));
		lbl_Lunes.setPreferredSize(new Dimension(187, 14));
		lbl_Lunes.setOpaque(true);
		lbl_Lunes.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Lunes.setForeground(Color.WHITE);
		lbl_Lunes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Lunes.setBackground(Color.GRAY);
		lbl_Lunes.setBounds(117, 192, 103, 30);
		contentPane.add(lbl_Lunes);
		
		JLabel lbl_Martes= new JLabel("Martes");
		lbl_Martes.setLocation(new Point(230, 190));
		lbl_Martes.setSize(new Dimension(100, 30));
		lbl_Martes.setPreferredSize(new Dimension(187, 14));
		lbl_Martes.setOpaque(true);
		lbl_Martes.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Martes.setForeground(Color.WHITE);
		lbl_Martes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Martes.setBackground(Color.GRAY);
		lbl_Martes.setBounds(218, 192, 103, 30);
		contentPane.add(lbl_Martes);
		
		JLabel lbl_Miercoles = new JLabel("Miercoles");
		lbl_Miercoles.setSize(new Dimension(100, 30));
		lbl_Miercoles.setPreferredSize(new Dimension(187, 14));
		lbl_Miercoles.setOpaque(true);
		lbl_Miercoles.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Miercoles.setForeground(Color.WHITE);
		lbl_Miercoles.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Miercoles.setBackground(Color.GRAY);
		lbl_Miercoles.setBounds(321, 192, 103, 30);
		contentPane.add(lbl_Miercoles);
		
		JLabel lbl_Jueves = new JLabel("Jueves");
		lbl_Jueves.setSize(new Dimension(100, 30));
		lbl_Jueves.setPreferredSize(new Dimension(187, 14));
		lbl_Jueves.setOpaque(true);
		lbl_Jueves.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Jueves.setForeground(Color.WHITE);
		lbl_Jueves.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Jueves.setBackground(Color.GRAY);
		lbl_Jueves.setBounds(421, 192, 103, 30);
		contentPane.add(lbl_Jueves);
		
		JLabel lbl_Viernes = new JLabel("Viernes");
		lbl_Viernes.setSize(new Dimension(100, 30));
		lbl_Viernes.setPreferredSize(new Dimension(187, 14));
		lbl_Viernes.setOpaque(true);
		lbl_Viernes.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Viernes.setForeground(Color.WHITE);
		lbl_Viernes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_Viernes.setBackground(Color.GRAY);
		lbl_Viernes.setBounds(519, 192, 103, 30);
		contentPane.add(lbl_Viernes);
		
		JLabel label_1 = new JLabel("7:20-8:30");
		label_1.setSize(new Dimension(100, 30));
		label_1.setPreferredSize(new Dimension(187, 14));
		label_1.setOpaque(true);
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_1.setBackground(new Color(220, 220, 220));
		label_1.setBounds(12, 227, 103, 30);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("8:30-9:30");
		label_2.setSize(new Dimension(100, 30));
		label_2.setPreferredSize(new Dimension(187, 14));
		label_2.setOpaque(true);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_2.setBackground(new Color(192, 192, 192));
		label_2.setBounds(12, 256, 103, 30);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("9:30-10:30");
		label_3.setSize(new Dimension(100, 30));
		label_3.setPreferredSize(new Dimension(187, 14));
		label_3.setOpaque(true);
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_3.setBackground(new Color(220, 220, 220));
		label_3.setBounds(12, 283, 103, 30);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("10:30-11:30");
		label_4.setSize(new Dimension(100, 30));
		label_4.setPreferredSize(new Dimension(187, 14));
		label_4.setOpaque(true);
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_4.setBackground(new Color(192, 192, 192));
		label_4.setBounds(12, 313, 103, 30);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("11:30-12:30");
		label_5.setSize(new Dimension(100, 30));
		label_5.setPreferredSize(new Dimension(187, 14));
		label_5.setOpaque(true);
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_5.setBackground(new Color(220, 220, 220));
		label_5.setBounds(12, 341, 103, 30);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("12:30-1:30");
		label_6.setSize(new Dimension(100, 30));
		label_6.setPreferredSize(new Dimension(187, 14));
		label_6.setOpaque(true);
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_6.setBackground(new Color(192, 192, 192));
		label_6.setBounds(12, 370, 103, 30);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("1:30-2:30");
		label_7.setSize(new Dimension(100, 30));
		label_7.setPreferredSize(new Dimension(187, 14));
		label_7.setOpaque(true);
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_7.setBackground(new Color(220, 220, 220));
		label_7.setBounds(12, 398, 103, 30);
		contentPane.add(label_7);
		
		JLabel label_8 = new JLabel("2:30-3:30");
		label_8.setSize(new Dimension(100, 30));
		label_8.setPreferredSize(new Dimension(187, 14));
		label_8.setOpaque(true);
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_8.setBackground(new Color(192, 192, 192));
		label_8.setBounds(12, 428, 103, 30);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel("3:30-4:30");
		label_9.setSize(new Dimension(100, 30));
		label_9.setPreferredSize(new Dimension(187, 14));
		label_9.setOpaque(true);
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_9.setBackground(new Color(220, 220, 220));
		label_9.setBounds(12, 456, 103, 30);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("4:30-5:30");
		label_10.setSize(new Dimension(100, 30));
		label_10.setPreferredSize(new Dimension(187, 14));
		label_10.setOpaque(true);
		label_10.setHorizontalAlignment(SwingConstants.CENTER);
		label_10.setForeground(Color.WHITE);
		label_10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_10.setBackground(new Color(192, 192, 192));
		label_10.setBounds(12, 481, 103, 30);
		contentPane.add(label_10);
		
			
		
		JLabel lbl_L1 = new JLabel("Hora");
		lbl_L1.setSize(new Dimension(100, 30));
		lbl_L1.setPreferredSize(new Dimension(187, 14));
		lbl_L1.setOpaque(true);
		lbl_L1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L1.setForeground(Color.WHITE);
		lbl_L1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L1.setBackground(new Color(220, 220, 220));
		lbl_L1.setBounds(117, 227, 103, 30);
		contentPane.add(lbl_L1);
		
		JLabel label_M1 = new JLabel("Hora");
		label_M1.setSize(new Dimension(100, 30));
		label_M1.setPreferredSize(new Dimension(187, 14));
		label_M1.setOpaque(true);
		label_M1.setHorizontalAlignment(SwingConstants.CENTER);
		label_M1.setForeground(Color.WHITE);
		label_M1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M1.setBackground(new Color(220, 220, 220));
		label_M1.setBounds(218, 227, 103, 30);
		contentPane.add(label_M1);
		
		JLabel label_I1 = new JLabel("Hora");
		label_I1.setSize(new Dimension(100, 30));
		label_I1.setPreferredSize(new Dimension(187, 14));
		label_I1.setOpaque(true);
		label_I1.setHorizontalAlignment(SwingConstants.CENTER);
		label_I1.setForeground(Color.WHITE);
		label_I1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I1.setBackground(new Color(220, 220, 220));
		label_I1.setBounds(321, 227, 103, 30);
		contentPane.add(label_I1);
		
		JLabel label_J1 = new JLabel("Hora");
		label_J1.setSize(new Dimension(100, 30));
		label_J1.setPreferredSize(new Dimension(187, 14));
		label_J1.setOpaque(true);
		label_J1.setHorizontalAlignment(SwingConstants.CENTER);
		label_J1.setForeground(Color.WHITE);
		label_J1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J1.setBackground(new Color(220, 220, 220));
		label_J1.setBounds(421, 227, 103, 30);
		contentPane.add(label_J1);
		
		JLabel label_V1 = new JLabel("Hora");
		label_V1.setSize(new Dimension(100, 30));
		label_V1.setPreferredSize(new Dimension(187, 14));
		label_V1.setOpaque(true);
		label_V1.setHorizontalAlignment(SwingConstants.CENTER);
		label_V1.setForeground(Color.WHITE);
		label_V1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V1.setBackground(new Color(220, 220, 220));
		label_V1.setBounds(519, 227, 103, 30);
		contentPane.add(label_V1);
		
		JLabel lbl_L2 = new JLabel("Hora");
		lbl_L2.setSize(new Dimension(100, 30));
		lbl_L2.setPreferredSize(new Dimension(187, 14));
		lbl_L2.setOpaque(true);
		lbl_L2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L2.setForeground(Color.WHITE);
		lbl_L2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L2.setBackground(Color.LIGHT_GRAY);
		lbl_L2.setBounds(117, 256, 103, 30);
		contentPane.add(lbl_L2);
		
		JLabel label_M2 = new JLabel("Hora");
		label_M2.setSize(new Dimension(100, 30));
		label_M2.setPreferredSize(new Dimension(187, 14));
		label_M2.setOpaque(true);
		label_M2.setHorizontalAlignment(SwingConstants.CENTER);
		label_M2.setForeground(Color.WHITE);
		label_M2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M2.setBackground(Color.LIGHT_GRAY);
		label_M2.setBounds(218, 256, 103, 30);
		contentPane.add(label_M2);
		
		JLabel label_I2 = new JLabel("Hora");
		label_I2.setSize(new Dimension(100, 30));
		label_I2.setPreferredSize(new Dimension(187, 14));
		label_I2.setOpaque(true);
		label_I2.setHorizontalAlignment(SwingConstants.CENTER);
		label_I2.setForeground(Color.WHITE);
		label_I2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I2.setBackground(Color.LIGHT_GRAY);
		label_I2.setBounds(321, 256, 103, 30);
		contentPane.add(label_I2);
		
		JLabel label_J2 = new JLabel("Hora");
		label_J2.setSize(new Dimension(100, 30));
		label_J2.setPreferredSize(new Dimension(187, 14));
		label_J2.setOpaque(true);
		label_J2.setHorizontalAlignment(SwingConstants.CENTER);
		label_J2.setForeground(Color.WHITE);
		label_J2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J2.setBackground(Color.LIGHT_GRAY);
		label_J2.setBounds(421, 256, 103, 30);
		contentPane.add(label_J2);
		
		JLabel label_V2 = new JLabel("Hora");
		label_V2.setSize(new Dimension(100, 30));
		label_V2.setPreferredSize(new Dimension(187, 14));
		label_V2.setOpaque(true);
		label_V2.setHorizontalAlignment(SwingConstants.CENTER);
		label_V2.setForeground(Color.WHITE);
		label_V2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V2.setBackground(Color.LIGHT_GRAY);
		label_V2.setBounds(519, 256, 103, 30);
		contentPane.add(label_V2);
		
		JLabel lbl_L3 = new JLabel("Hora");
		lbl_L3.setSize(new Dimension(100, 30));
		lbl_L3.setPreferredSize(new Dimension(187, 14));
		lbl_L3.setOpaque(true);
		lbl_L3.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L3.setForeground(Color.WHITE);
		lbl_L3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L3.setBackground(new Color(220, 220, 220));
		lbl_L3.setBounds(117, 283, 103, 30);
		contentPane.add(lbl_L3);
		
		JLabel label_M3 = new JLabel("Hora");
		label_M3.setSize(new Dimension(100, 30));
		label_M3.setPreferredSize(new Dimension(187, 14));
		label_M3.setOpaque(true);
		label_M3.setHorizontalAlignment(SwingConstants.CENTER);
		label_M3.setForeground(Color.WHITE);
		label_M3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M3.setBackground(new Color(220, 220, 220));
		label_M3.setBounds(218, 283, 103, 30);
		contentPane.add(label_M3);
		
		JLabel label_I3 = new JLabel("Hora");
		label_I3.setSize(new Dimension(100, 30));
		label_I3.setPreferredSize(new Dimension(187, 14));
		label_I3.setOpaque(true);
		label_I3.setHorizontalAlignment(SwingConstants.CENTER);
		label_I3.setForeground(Color.WHITE);
		label_I3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I3.setBackground(new Color(220, 220, 220));
		label_I3.setBounds(321, 283, 103, 30);
		contentPane.add(label_I3);
		
		JLabel lbl_L4 = new JLabel("Hora");
		lbl_L4.setSize(new Dimension(100, 30));
		lbl_L4.setPreferredSize(new Dimension(187, 14));
		lbl_L4.setOpaque(true);
		lbl_L4.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L4.setForeground(Color.WHITE);
		lbl_L4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L4.setBackground(Color.LIGHT_GRAY);
		lbl_L4.setBounds(117, 313, 103, 30);
		contentPane.add(lbl_L4);
		
		JLabel label_J3 = new JLabel("Hora");
		label_J3.setSize(new Dimension(100, 30));
		label_J3.setPreferredSize(new Dimension(187, 14));
		label_J3.setOpaque(true);
		label_J3.setHorizontalAlignment(SwingConstants.CENTER);
		label_J3.setForeground(Color.WHITE);
		label_J3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J3.setBackground(new Color(220, 220, 220));
		label_J3.setBounds(421, 283, 103, 30);
		contentPane.add(label_J3);
		
		JLabel label_V3 = new JLabel("Hora");
		label_V3.setSize(new Dimension(100, 30));
		label_V3.setPreferredSize(new Dimension(187, 14));
		label_V3.setOpaque(true);
		label_V3.setHorizontalAlignment(SwingConstants.CENTER);
		label_V3.setForeground(Color.WHITE);
		label_V3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V3.setBackground(new Color(220, 220, 220));
		label_V3.setBounds(519, 283, 103, 30);
		contentPane.add(label_V3);
		
		JLabel label_M4 = new JLabel("Hora");
		label_M4.setSize(new Dimension(100, 30));
		label_M4.setPreferredSize(new Dimension(187, 14));
		label_M4.setOpaque(true);
		label_M4.setHorizontalAlignment(SwingConstants.CENTER);
		label_M4.setForeground(Color.WHITE);
		label_M4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M4.setBackground(Color.LIGHT_GRAY);
		label_M4.setBounds(218, 313, 103, 30);
		contentPane.add(label_M4);
		
		JLabel label_I4 = new JLabel("Hora");
		label_I4.setSize(new Dimension(100, 30));
		label_I4.setPreferredSize(new Dimension(187, 14));
		label_I4.setOpaque(true);
		label_I4.setHorizontalAlignment(SwingConstants.CENTER);
		label_I4.setForeground(Color.WHITE);
		label_I4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I4.setBackground(Color.LIGHT_GRAY);
		label_I4.setBounds(321, 313, 103, 30);
		contentPane.add(label_I4);
		
		JLabel label_V4 = new JLabel("Hora");
		label_V4.setSize(new Dimension(100, 30));
		label_V4.setPreferredSize(new Dimension(187, 14));
		label_V4.setOpaque(true);
		label_V4.setHorizontalAlignment(SwingConstants.CENTER);
		label_V4.setForeground(Color.WHITE);
		label_V4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V4.setBackground(Color.LIGHT_GRAY);
		label_V4.setBounds(519, 313, 103, 30);
		contentPane.add(label_V4);
		
		JLabel label_J4 = new JLabel("Hora");
		label_J4.setSize(new Dimension(100, 30));
		label_J4.setPreferredSize(new Dimension(187, 14));
		label_J4.setOpaque(true);
		label_J4.setHorizontalAlignment(SwingConstants.CENTER);
		label_J4.setForeground(Color.WHITE);
		label_J4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J4.setBackground(Color.LIGHT_GRAY);
		label_J4.setBounds(421, 313, 103, 30);
		contentPane.add(label_J4);
		
		JLabel lbl_L5 = new JLabel("Hora");
		lbl_L5.setSize(new Dimension(100, 30));
		lbl_L5.setPreferredSize(new Dimension(187, 14));
		lbl_L5.setOpaque(true);
		lbl_L5.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L5.setForeground(Color.WHITE);
		lbl_L5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L5.setBackground(new Color(220, 220, 220));
		lbl_L5.setBounds(117, 341, 103, 30);
		contentPane.add(lbl_L5);
		
		JLabel label_M5 = new JLabel("Hora");
		label_M5.setSize(new Dimension(100, 30));
		label_M5.setPreferredSize(new Dimension(187, 14));
		label_M5.setOpaque(true);
		label_M5.setHorizontalAlignment(SwingConstants.CENTER);
		label_M5.setForeground(Color.WHITE);
		label_M5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M5.setBackground(new Color(220, 220, 220));
		label_M5.setBounds(218, 341, 103, 30);
		contentPane.add(label_M5);
		
		JLabel label_I5 = new JLabel("Hora");
		label_I5.setSize(new Dimension(100, 30));
		label_I5.setPreferredSize(new Dimension(187, 14));
		label_I5.setOpaque(true);
		label_I5.setHorizontalAlignment(SwingConstants.CENTER);
		label_I5.setForeground(Color.WHITE);
		label_I5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I5.setBackground(new Color(220, 220, 220));
		label_I5.setBounds(321, 341, 103, 30);
		contentPane.add(label_I5);
		
		JLabel label_J5 = new JLabel("Hora");
		label_J5.setSize(new Dimension(100, 30));
		label_J5.setPreferredSize(new Dimension(187, 14));
		label_J5.setOpaque(true);
		label_J5.setHorizontalAlignment(SwingConstants.CENTER);
		label_J5.setForeground(Color.WHITE);
		label_J5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J5.setBackground(new Color(220, 220, 220));
		label_J5.setBounds(421, 341, 103, 30);
		contentPane.add(label_J5);
		
		JLabel label_V5 = new JLabel("Hora");
		label_V5.setSize(new Dimension(100, 30));
		label_V5.setPreferredSize(new Dimension(187, 14));
		label_V5.setOpaque(true);
		label_V5.setHorizontalAlignment(SwingConstants.CENTER);
		label_V5.setForeground(Color.WHITE);
		label_V5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V5.setBackground(new Color(220, 220, 220));
		label_V5.setBounds(519, 341, 103, 30);
		contentPane.add(label_V5);
		
		JLabel lbl_L6 = new JLabel("Hora");
		lbl_L6.setSize(new Dimension(100, 30));
		lbl_L6.setPreferredSize(new Dimension(187, 14));
		lbl_L6.setOpaque(true);
		lbl_L6.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L6.setForeground(Color.WHITE);
		lbl_L6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L6.setBackground(Color.LIGHT_GRAY);
		lbl_L6.setBounds(117, 370, 103, 30);
		contentPane.add(lbl_L6);
		
		JLabel label_M6 = new JLabel("Hora");
		label_M6.setSize(new Dimension(100, 30));
		label_M6.setPreferredSize(new Dimension(187, 14));
		label_M6.setOpaque(true);
		label_M6.setHorizontalAlignment(SwingConstants.CENTER);
		label_M6.setForeground(Color.WHITE);
		label_M6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M6.setBackground(Color.LIGHT_GRAY);
		label_M6.setBounds(218, 370, 103, 30);
		contentPane.add(label_M6);
		
		JLabel label_I6 = new JLabel("Hora");
		label_I6.setSize(new Dimension(100, 30));
		label_I6.setPreferredSize(new Dimension(187, 14));
		label_I6.setOpaque(true);
		label_I6.setHorizontalAlignment(SwingConstants.CENTER);
		label_I6.setForeground(Color.WHITE);
		label_I6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I6.setBackground(Color.LIGHT_GRAY);
		label_I6.setBounds(321, 370, 103, 30);
		contentPane.add(label_I6);
		
		JLabel label_J6 = new JLabel("Hora");
		label_J6.setSize(new Dimension(100, 30));
		label_J6.setPreferredSize(new Dimension(187, 14));
		label_J6.setOpaque(true);
		label_J6.setHorizontalAlignment(SwingConstants.CENTER);
		label_J6.setForeground(Color.WHITE);
		label_J6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J6.setBackground(Color.LIGHT_GRAY);
		label_J6.setBounds(421, 370, 103, 30);
		contentPane.add(label_J6);
		
		JLabel label_V6 = new JLabel("Hora");
		label_V6.setSize(new Dimension(100, 30));
		label_V6.setPreferredSize(new Dimension(187, 14));
		label_V6.setOpaque(true);
		label_V6.setHorizontalAlignment(SwingConstants.CENTER);
		label_V6.setForeground(Color.WHITE);
		label_V6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V6.setBackground(Color.LIGHT_GRAY);
		label_V6.setBounds(519, 370, 103, 30);
		contentPane.add(label_V6);
		
		JLabel lbl_L7 = new JLabel("Hora");
		lbl_L7.setSize(new Dimension(100, 30));
		lbl_L7.setPreferredSize(new Dimension(187, 14));
		lbl_L7.setOpaque(true);
		lbl_L7.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L7.setForeground(Color.WHITE);
		lbl_L7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L7.setBackground(new Color(220, 220, 220));
		lbl_L7.setBounds(117, 398, 103, 30);
		contentPane.add(lbl_L7);
		
		JLabel label_M7 = new JLabel("Hora");
		label_M7.setSize(new Dimension(100, 30));
		label_M7.setPreferredSize(new Dimension(187, 14));
		label_M7.setOpaque(true);
		label_M7.setHorizontalAlignment(SwingConstants.CENTER);
		label_M7.setForeground(Color.WHITE);
		label_M7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M7.setBackground(new Color(220, 220, 220));
		label_M7.setBounds(218, 398, 103, 30);
		contentPane.add(label_M7);
		
		JLabel label_I7 = new JLabel("Hora");
		label_I7.setSize(new Dimension(100, 30));
		label_I7.setPreferredSize(new Dimension(187, 14));
		label_I7.setOpaque(true);
		label_I7.setHorizontalAlignment(SwingConstants.CENTER);
		label_I7.setForeground(Color.WHITE);
		label_I7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I7.setBackground(new Color(220, 220, 220));
		label_I7.setBounds(321, 398, 103, 30);
		contentPane.add(label_I7);
		
		JLabel label_J7 = new JLabel("Hora");
		label_J7.setSize(new Dimension(100, 30));
		label_J7.setPreferredSize(new Dimension(187, 14));
		label_J7.setOpaque(true);
		label_J7.setHorizontalAlignment(SwingConstants.CENTER);
		label_J7.setForeground(Color.WHITE);
		label_J7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J7.setBackground(new Color(220, 220, 220));
		label_J7.setBounds(421, 398, 103, 30);
		contentPane.add(label_J7);
		
		JLabel label_V7 = new JLabel("Hora");
		label_V7.setSize(new Dimension(100, 30));
		label_V7.setPreferredSize(new Dimension(187, 14));
		label_V7.setOpaque(true);
		label_V7.setHorizontalAlignment(SwingConstants.CENTER);
		label_V7.setForeground(Color.WHITE);
		label_V7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V7.setBackground(new Color(220, 220, 220));
		label_V7.setBounds(519, 398, 103, 30);
		contentPane.add(label_V7);
		
		JLabel lbl_L8 = new JLabel("Hora");
		lbl_L8.setSize(new Dimension(100, 30));
		lbl_L8.setPreferredSize(new Dimension(187, 14));
		lbl_L8.setOpaque(true);
		lbl_L8.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L8.setForeground(Color.WHITE);
		lbl_L8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L8.setBackground(Color.LIGHT_GRAY);
		lbl_L8.setBounds(117, 428, 103, 30);
		contentPane.add(lbl_L8);
		
		JLabel label_M8 = new JLabel("Hora");
		label_M8.setSize(new Dimension(100, 30));
		label_M8.setPreferredSize(new Dimension(187, 14));
		label_M8.setOpaque(true);
		label_M8.setHorizontalAlignment(SwingConstants.CENTER);
		label_M8.setForeground(Color.WHITE);
		label_M8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M8.setBackground(Color.LIGHT_GRAY);
		label_M8.setBounds(218, 428, 103, 30);
		contentPane.add(label_M8);
		
		JLabel label_I8 = new JLabel("Hora");
		label_I8.setSize(new Dimension(100, 30));
		label_I8.setPreferredSize(new Dimension(187, 14));
		label_I8.setOpaque(true);
		label_I8.setHorizontalAlignment(SwingConstants.CENTER);
		label_I8.setForeground(Color.WHITE);
		label_I8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I8.setBackground(Color.LIGHT_GRAY);
		label_I8.setBounds(321, 428, 103, 30);
		contentPane.add(label_I8);
		
		JLabel label_J8 = new JLabel("Hora");
		label_J8.setSize(new Dimension(100, 30));
		label_J8.setPreferredSize(new Dimension(187, 14));
		label_J8.setOpaque(true);
		label_J8.setHorizontalAlignment(SwingConstants.CENTER);
		label_J8.setForeground(Color.WHITE);
		label_J8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J8.setBackground(Color.LIGHT_GRAY);
		label_J8.setBounds(421, 428, 103, 30);
		contentPane.add(label_J8);
		
		JLabel label_V8 = new JLabel("Hora");
		label_V8.setSize(new Dimension(100, 30));
		label_V8.setPreferredSize(new Dimension(187, 14));
		label_V8.setOpaque(true);
		label_V8.setHorizontalAlignment(SwingConstants.CENTER);
		label_V8.setForeground(Color.WHITE);
		label_V8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V8.setBackground(Color.LIGHT_GRAY);
		label_V8.setBounds(519, 428, 103, 30);
		contentPane.add(label_V8);
		
		JLabel lbl_L9 = new JLabel("Hora");
		lbl_L9.setSize(new Dimension(100, 30));
		lbl_L9.setPreferredSize(new Dimension(187, 14));
		lbl_L9.setOpaque(true);
		lbl_L9.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L9.setForeground(Color.WHITE);
		lbl_L9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L9.setBackground(new Color(220, 220, 220));
		lbl_L9.setBounds(117, 456, 103, 30);
		contentPane.add(lbl_L9);
		
		JLabel label_M9 = new JLabel("Hora");
		label_M9.setSize(new Dimension(100, 30));
		label_M9.setPreferredSize(new Dimension(187, 14));
		label_M9.setOpaque(true);
		label_M9.setHorizontalAlignment(SwingConstants.CENTER);
		label_M9.setForeground(Color.WHITE);
		label_M9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M9.setBackground(new Color(220, 220, 220));
		label_M9.setBounds(218, 456, 103, 30);
		contentPane.add(label_M9);
		
		JLabel label_I9 = new JLabel("Hora");
		label_I9.setSize(new Dimension(100, 30));
		label_I9.setPreferredSize(new Dimension(187, 14));
		label_I9.setOpaque(true);
		label_I9.setHorizontalAlignment(SwingConstants.CENTER);
		label_I9.setForeground(Color.WHITE);
		label_I9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I9.setBackground(new Color(220, 220, 220));
		label_I9.setBounds(321, 456, 103, 30);
		contentPane.add(label_I9);
		
		JLabel lbl_L10 = new JLabel("Hora");
		lbl_L10.setSize(new Dimension(100, 30));
		lbl_L10.setPreferredSize(new Dimension(187, 14));
		lbl_L10.setOpaque(true);
		lbl_L10.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_L10.setForeground(Color.WHITE);
		lbl_L10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lbl_L10.setBackground(Color.LIGHT_GRAY);
		lbl_L10.setBounds(117, 481, 103, 30);
		contentPane.add(lbl_L10);
		
		JLabel label_M10 = new JLabel("Hora");
		label_M10.setSize(new Dimension(100, 30));
		label_M10.setPreferredSize(new Dimension(187, 14));
		label_M10.setOpaque(true);
		label_M10.setHorizontalAlignment(SwingConstants.CENTER);
		label_M10.setForeground(Color.WHITE);
		label_M10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_M10.setBackground(Color.LIGHT_GRAY);
		label_M10.setBounds(218, 481, 103, 30);
		contentPane.add(label_M10);
		
		JLabel label_I10 = new JLabel("Hora");
		label_I10.setSize(new Dimension(100, 30));
		label_I10.setPreferredSize(new Dimension(187, 14));
		label_I10.setOpaque(true);
		label_I10.setHorizontalAlignment(SwingConstants.CENTER);
		label_I10.setForeground(Color.WHITE);
		label_I10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_I10.setBackground(Color.LIGHT_GRAY);
		label_I10.setBounds(321, 481, 103, 30);
		contentPane.add(label_I10);
		
		JLabel label_J9 = new JLabel("Hora");
		label_J9.setSize(new Dimension(100, 30));
		label_J9.setPreferredSize(new Dimension(187, 14));
		label_J9.setOpaque(true);
		label_J9.setHorizontalAlignment(SwingConstants.CENTER);
		label_J9.setForeground(Color.WHITE);
		label_J9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J9.setBackground(new Color(220, 220, 220));
		label_J9.setBounds(421, 456, 103, 30);
		contentPane.add(label_J9);
		
		JLabel label_V9 = new JLabel("Hora");
		label_V9.setSize(new Dimension(100, 30));
		label_V9.setPreferredSize(new Dimension(187, 14));
		label_V9.setOpaque(true);
		label_V9.setHorizontalAlignment(SwingConstants.CENTER);
		label_V9.setForeground(Color.WHITE);
		label_V9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V9.setBackground(new Color(220, 220, 220));
		label_V9.setBounds(519, 456, 103, 30);
		contentPane.add(label_V9);
		
		JLabel label_J10 = new JLabel("Hora");
		label_J10.setSize(new Dimension(100, 30));
		label_J10.setPreferredSize(new Dimension(187, 14));
		label_J10.setOpaque(true);
		label_J10.setHorizontalAlignment(SwingConstants.CENTER);
		label_J10.setForeground(Color.WHITE);
		label_J10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_J10.setBackground(Color.LIGHT_GRAY);
		label_J10.setBounds(421, 481, 103, 30);
		contentPane.add(label_J10);
		
		JLabel label_V10 = new JLabel("Hora");
		label_V10.setSize(new Dimension(100, 30));
		label_V10.setPreferredSize(new Dimension(187, 14));
		label_V10.setOpaque(true);
		label_V10.setHorizontalAlignment(SwingConstants.CENTER);
		label_V10.setForeground(Color.WHITE);
		label_V10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		label_V10.setBackground(Color.LIGHT_GRAY);
		label_V10.setBounds(519, 481, 103, 30);
		contentPane.add(label_V10);
		
		switch (l){
		case 0:
			lbl_L1.setText(maestros[e].getClase(0,0));
			lbl_L2.setText(maestros[e].getClase(1,0));
			lbl_L3.setText(maestros[e].getClase(2,0));
			lbl_L4.setText(maestros[e].getClase(3,0));
			lbl_L5.setText(maestros[e].getClase(4,0));
			lbl_L6.setText(maestros[e].getClase(5,0));
			lbl_L7.setText(maestros[e].getClase(6,0));
			lbl_L8.setText(maestros[e].getClase(7,0));
			lbl_L9.setText(maestros[e].getClase(8,0));
			lbl_L10.setText(maestros[e].getClase(9,0));
			label_M1.setText(maestros[e].getClase(0,1));
			label_M2.setText(maestros[e].getClase(1,1));
			label_M3.setText(maestros[e].getClase(2,1));
			label_M4.setText(maestros[e].getClase(3,1));
			label_M5.setText(maestros[e].getClase(4,1));
			label_M6.setText(maestros[e].getClase(5,1));
			label_M7.setText(maestros[e].getClase(6,1));
			label_M8.setText(maestros[e].getClase(7,1));
			label_M9.setText(maestros[e].getClase(8,1));
			label_M10.setText(maestros[e].getClase(9,1));
			label_I1.setText(maestros[e].getClase(0,2));
			label_I2.setText(maestros[e].getClase(1,2));
			label_I3.setText(maestros[e].getClase(2,2));
			label_I4.setText(maestros[e].getClase(3,2));
			label_I5.setText(maestros[e].getClase(4,2));
			label_I6.setText(maestros[e].getClase(5,2));
			label_I7.setText(maestros[e].getClase(6,2));
			label_I8.setText(maestros[e].getClase(7,2));
			label_I9.setText(maestros[e].getClase(8,2));
			label_I10.setText(maestros[e].getClase(9,2));
			label_J1.setText(maestros[e].getClase(0,3));
			label_J2.setText(maestros[e].getClase(1,3));
			label_J3.setText(maestros[e].getClase(2,3));
			label_J4.setText(maestros[e].getClase(3,3));
			label_J5.setText(maestros[e].getClase(4,3));
			label_J6.setText(maestros[e].getClase(5,3));
			label_J7.setText(maestros[e].getClase(6,3));
			label_J8.setText(maestros[e].getClase(7,3));
			label_J9.setText(maestros[e].getClase(8,3));
			label_J10.setText(maestros[e].getClase(9,3));
			label_V1.setText(maestros[e].getClase(0,4));
			label_V2.setText(maestros[e].getClase(1,4));
			label_V3.setText(maestros[e].getClase(2,4));
			label_V4.setText(maestros[e].getClase(3,4));
			label_V5.setText(maestros[e].getClase(4,4));
			label_V6.setText(maestros[e].getClase(5,4));
			label_V7.setText(maestros[e].getClase(6,4));
			label_V8.setText(maestros[e].getClase(7,4));
			label_V9.setText(maestros[e].getClase(8,4));
			label_V10.setText(maestros[e].getClase(9,4));
		break;
		case 1: 
			lbl_L1.setText(maestros[e].getSalon(0,0));
			lbl_L2.setText(maestros[e].getSalon(1,0));
			lbl_L3.setText(maestros[e].getSalon(2,0));
			lbl_L4.setText(maestros[e].getSalon(3,0));
			lbl_L5.setText(maestros[e].getSalon(4,0));
			lbl_L6.setText(maestros[e].getSalon(5,0));
			lbl_L7.setText(maestros[e].getSalon(6,0));
			lbl_L8.setText(maestros[e].getSalon(7,0));
			lbl_L9.setText(maestros[e].getSalon(8,0));
			lbl_L10.setText(maestros[e].getSalon(9,0));
			label_M1.setText(maestros[e].getSalon(0,1));
			label_M2.setText(maestros[e].getSalon(1,1));
			label_M3.setText(maestros[e].getSalon(2,1));
			label_M4.setText(maestros[e].getSalon(3,1));
			label_M5.setText(maestros[e].getSalon(4,1));
			label_M6.setText(maestros[e].getSalon(5,1));
			label_M7.setText(maestros[e].getSalon(6,1));
			label_M8.setText(maestros[e].getSalon(7,1));
			label_M9.setText(maestros[e].getSalon(8,1));
			label_M10.setText(maestros[e].getSalon(9,1));
			label_I1.setText(maestros[e].getSalon(0,2));
			label_I2.setText(maestros[e].getSalon(1,2));
			label_I3.setText(maestros[e].getSalon(2,2));
			label_I4.setText(maestros[e].getSalon(3,2));
			label_I5.setText(maestros[e].getSalon(4,2));
			label_I6.setText(maestros[e].getSalon(5,2));
			label_I7.setText(maestros[e].getSalon(6,2));
			label_I8.setText(maestros[e].getSalon(7,2));
			label_I9.setText(maestros[e].getSalon(8,2));
			label_I10.setText(maestros[e].getSalon(9,2));
			label_J1.setText(maestros[e].getSalon(0,3));
			label_J2.setText(maestros[e].getSalon(1,3));
			label_J3.setText(maestros[e].getSalon(2,3));
			label_J4.setText(maestros[e].getSalon(3,3));
			label_J5.setText(maestros[e].getSalon(4,3));
			label_J6.setText(maestros[e].getSalon(5,3));
			label_J7.setText(maestros[e].getSalon(6,3));
			label_J8.setText(maestros[e].getSalon(7,3));
			label_J9.setText(maestros[e].getSalon(8,3));
			label_J10.setText(maestros[e].getSalon(9,3));
			label_V1.setText(maestros[e].getSalon(0,4));
			label_V2.setText(maestros[e].getSalon(1,4));
			label_V3.setText(maestros[e].getSalon(2,4));
			label_V4.setText(maestros[e].getSalon(3,4));
			label_V5.setText(maestros[e].getSalon(4,4));
			label_V6.setText(maestros[e].getSalon(5,4));
			label_V7.setText(maestros[e].getSalon(6,4));
			label_V8.setText(maestros[e].getSalon(7,4));
			label_V9.setText(maestros[e].getSalon(8,4));
			label_V10.setText(maestros[e].getSalon(9,4));
			break;
		case 2: 
			lbl_L1.setText(maestros[e].getGrupo(0,0));
			lbl_L2.setText(maestros[e].getGrupo(1,0));
			lbl_L3.setText(maestros[e].getGrupo(2,0));
			lbl_L4.setText(maestros[e].getGrupo(3,0));
			lbl_L5.setText(maestros[e].getGrupo(4,0));
			lbl_L6.setText(maestros[e].getGrupo(5,0));
			lbl_L7.setText(maestros[e].getGrupo(6,0));
			lbl_L8.setText(maestros[e].getGrupo(7,0));
			lbl_L9.setText(maestros[e].getGrupo(8,0));
			lbl_L10.setText(maestros[e].getGrupo(9,0));
			label_M1.setText(maestros[e].getGrupo(0,1));
			label_M2.setText(maestros[e].getGrupo(1,1));
			label_M3.setText(maestros[e].getGrupo(2,1));
			label_M4.setText(maestros[e].getGrupo(3,1));
			label_M5.setText(maestros[e].getGrupo(4,1));
			label_M6.setText(maestros[e].getGrupo(5,1));
			label_M7.setText(maestros[e].getGrupo(6,1));
			label_M8.setText(maestros[e].getGrupo(7,1));
			label_M9.setText(maestros[e].getGrupo(8,1));
			label_M10.setText(maestros[e].getGrupo(9,1));
			label_I1.setText(maestros[e].getGrupo(0,2));
			label_I2.setText(maestros[e].getGrupo(1,2));
			label_I3.setText(maestros[e].getGrupo(2,2));
			label_I4.setText(maestros[e].getGrupo(3,2));
			label_I5.setText(maestros[e].getGrupo(4,2));
			label_I6.setText(maestros[e].getGrupo(5,2));
			label_I7.setText(maestros[e].getGrupo(6,2));
			label_I8.setText(maestros[e].getGrupo(7,2));
			label_I9.setText(maestros[e].getGrupo(8,2));
			label_I10.setText(maestros[e].getGrupo(9,2));
			label_J1.setText(maestros[e].getGrupo(0,3));
			label_J2.setText(maestros[e].getGrupo(1,3));
			label_J3.setText(maestros[e].getGrupo(2,3));
			label_J4.setText(maestros[e].getGrupo(3,3));
			label_J5.setText(maestros[e].getGrupo(4,3));
			label_J6.setText(maestros[e].getGrupo(5,3));
			label_J7.setText(maestros[e].getGrupo(6,3));
			label_J8.setText(maestros[e].getGrupo(7,3));
			label_J9.setText(maestros[e].getGrupo(8,3));
			label_J10.setText(maestros[e].getGrupo(9,3));
			label_V1.setText(maestros[e].getGrupo(0,4));
			label_V2.setText(maestros[e].getGrupo(1,4));
			label_V3.setText(maestros[e].getGrupo(2,4));
			label_V4.setText(maestros[e].getGrupo(3,4));
			label_V5.setText(maestros[e].getGrupo(4,4));
			label_V6.setText(maestros[e].getGrupo(5,4));
			label_V7.setText(maestros[e].getGrupo(6,4));
			label_V8.setText(maestros[e].getGrupo(7,4));
			label_V9.setText(maestros[e].getGrupo(8,4));
			label_V10.setText(maestros[e].getGrupo(9,4));
			break;
		default: break;
		}
	}
}
