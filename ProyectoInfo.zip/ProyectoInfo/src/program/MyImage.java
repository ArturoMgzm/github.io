package program;

import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class MyImage {//https://www.youtube.com/watch?v=lGX0Gc6d51s and https://www.dyclassroom.com/image-processing-project/how-to-get-and-set-pixel-value-in-java
	public static void main(String args[]) throws IOException{
	}
	
	public static void Myimage(String nombre, String url) throws IOException{
		
		   File file = new File("\\Users\\" + System.getProperty("user.name") + "\\Documents\\HorariosTecImages");
	        if (!file.exists()) {
	        	file.mkdir();
	        }
		
		BufferedImage image = null, img = null;
		File f = null, g = null;
		
		try{
			g = new File(url);
			img = ImageIO.read(g);
			int width = img.getWidth();
			int height = img.getHeight();
			f = new File(url);
			image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
			image = ImageIO.read(f);

		}
		catch(IOException e) {}
		
		try{
			f = new File("\\Users\\" + System.getProperty("user.name") + "\\Documents\\HorariosTecImages\\" + nombre + ".jpg");
//					"C:\\Users\\Arturo\\Documents\\Informatica 2 BI\\Eclipse\\ProyectoInfo\\images\\" + nombre + ".jpg");
			ImageIO.write(image, "jpg", f);
		}
		catch(IOException e) {}
		
	}
}
